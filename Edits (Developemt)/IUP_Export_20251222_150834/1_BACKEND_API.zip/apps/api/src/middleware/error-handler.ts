import { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { AppError } from '../core/errors';

export async function errorHandler(error: FastifyError | AppError | Error, request: FastifyRequest, reply: FastifyReply) {
  // Handle core/errors.ts AppError (has toJSON method)
  if (error instanceof AppError) return reply.status(error.statusCode).send(error.toJSON());

  // Handle middleware/errors.ts AppError (has statusCode but no toJSON)
  if ('statusCode' in error && typeof error.statusCode === 'number') {
    const statusCode = error.statusCode;
    const message = error.message || 'An error occurred';

    if (statusCode === 400) return reply.status(400).send({ type: 'validation_error', message });
    if (statusCode === 401) return reply.status(401).send({ type: 'authentication_error', message });
    if (statusCode === 403) return reply.status(403).send({ type: 'authorization_error', message });
    if (statusCode === 404) return reply.status(404).send({ type: 'domain_violation', message });
    if (statusCode === 422) return reply.status(422).send({ type: 'validation_error', message });
  }

  // Handle Fastify validation errors
  if ('validation' in error) return reply.status(400).send({ type: 'validation_error', message: 'Validation failed', details: error.validation });

  // Log unexpected errors and return 500
  request.log.error(error);
  return reply.status(500).send({ type: 'system_failure', message: 'Unexpected error' });
}

export async function notFoundHandler(request: FastifyRequest, reply: FastifyReply) {
  return reply.status(404).send({
    type: 'domain_violation',
    message: `Route ${request.method} ${request.url} not found`
  });
}
