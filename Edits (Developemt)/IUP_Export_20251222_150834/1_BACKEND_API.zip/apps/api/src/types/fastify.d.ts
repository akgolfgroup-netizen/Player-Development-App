import { FastifyRequest, FastifyReply } from 'fastify';
import { PrismaClient, Tenant } from '@prisma/client';
import { AccessTokenPayload } from '../utils/jwt';

declare module 'fastify' {
  interface FastifyRequest {
    user?: AccessTokenPayload;
    tenant?: Tenant;
    db?: PrismaClient;
  }

  interface FastifyInstance {
    authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }
}

// Helper type for authenticated requests where user is guaranteed
export interface AuthenticatedRequest extends FastifyRequest {
  user: AccessTokenPayload;
}

// Helper type for requests with tenant context
export interface TenantRequest extends AuthenticatedRequest {
  tenant: Tenant;
  db: PrismaClient;
}
