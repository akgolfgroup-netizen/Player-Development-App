import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { AuthService } from './service';
import { getPrismaClient } from '../../../core/db/prisma';
import {
  registerSchema,
  loginSchema,
  refreshTokenSchema,
  logoutSchema,
  changePasswordSchema,
  RegisterInput,
  LoginInput,
  RefreshTokenInput,
  LogoutInput,
  ChangePasswordInput,
} from './schema';
import { authenticateUser } from '../../../middleware/auth';
import { validate } from '../../../utils/validation';

/**
 * Register auth routes
 */
export async function authRoutes(app: FastifyInstance): Promise<void> {
  const prisma = getPrismaClient();
  const authService = new AuthService(prisma);

  /**
   * Register a new user and organization
   */
  app.post<{ Body: RegisterInput }>(
    '/register',
    {
      schema: {
        description: 'Register a new user and create an organization',
        tags: ['auth'],
        response: {
          201: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              data: {
                type: 'object',
                properties: {
                  accessToken: { type: 'string' },
                  refreshToken: { type: 'string' },
                  expiresIn: { type: 'number', example: 900 },
                  user: {
                    type: 'object',
                    properties: {
                      id: { type: 'string' },
                      email: { type: 'string' },
                      firstName: { type: 'string' },
                      lastName: { type: 'string' },
                      role: { type: 'string' },
                      tenantId: { type: 'string' },
                    },
                  },
                },
              },
            },
          },
          409: { $ref: 'Error#' },
        },
      },
    },
    async (request: FastifyRequest<{ Body: RegisterInput }>, reply: FastifyReply) => {
      const input = validate(registerSchema, request.body);
      const result = await authService.register(input);
      return reply.code(201).send({ success: true, data: result });
    }
  );

  /**
   * Login with email and password
   */
  app.post<{ Body: LoginInput }>(
    '/login',
    {
      schema: {
        description: 'Login with email and password',
        tags: ['auth'],
        response: {
          200: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              data: {
                type: 'object',
                properties: {
                  accessToken: { type: 'string' },
                  refreshToken: { type: 'string' },
                  expiresIn: { type: 'number', example: 900 },
                  user: {
                    type: 'object',
                    properties: {
                      id: { type: 'string' },
                      email: { type: 'string' },
                      firstName: { type: 'string' },
                      lastName: { type: 'string' },
                      role: { type: 'string' },
                      tenantId: { type: 'string' },
                    },
                  },
                },
              },
            },
          },
          401: { $ref: 'Error#' },
        },
      },
    },
    async (request: FastifyRequest<{ Body: LoginInput }>, reply: FastifyReply) => {
      const input = validate(loginSchema, request.body);
      const result = await authService.login(input);
      return reply.send({ success: true, data: result });
    }
  );

  /**
   * Refresh access token
   */
  app.post<{ Body: RefreshTokenInput }>(
    '/refresh',
    {
      schema: {
        description: 'Refresh access token using refresh token',
        tags: ['auth'],
        response: {
          200: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              data: {
                type: 'object',
                properties: {
                  accessToken: { type: 'string' },
                  refreshToken: { type: 'string' },
                  expiresIn: { type: 'number', example: 900 },
                  user: {
                    type: 'object',
                    properties: {
                      id: { type: 'string' },
                      email: { type: 'string' },
                      firstName: { type: 'string' },
                      lastName: { type: 'string' },
                      role: { type: 'string' },
                      tenantId: { type: 'string' },
                    },
                  },
                },
              },
            },
          },
          401: { $ref: 'Error#' },
        },
      },
    },
    async (request: FastifyRequest<{ Body: RefreshTokenInput }>, reply: FastifyReply) => {
      const input = validate(refreshTokenSchema, request.body);
      const result = await authService.refreshAccessToken(input.refreshToken);
      return reply.send({ success: true, data: result });
    }
  );

  /**
   * Logout (revoke refresh token)
   */
  app.post<{ Body: LogoutInput }>(
    '/logout',
    {
      preHandler: [authenticateUser],
      schema: {
        description: 'Logout and revoke refresh token',
        tags: ['auth'],
        security: [{ bearerAuth: [] }],
        response: {
          200: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              message: { type: 'string', example: 'Logged out successfully' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: LogoutInput }>, reply: FastifyReply) => {
      const input = validate(logoutSchema, request.body);
      await authService.logout(input.refreshToken);
      return reply.send({ success: true, message: 'Logged out successfully' });
    }
  );

  /**
   * Change password (requires authentication)
   */
  app.post<{ Body: ChangePasswordInput }>(
    '/change-password',
    {
      preHandler: [authenticateUser],
      schema: {
        description: 'Change user password',
        tags: ['auth'],
        security: [{ bearerAuth: [] }],
        response: {
          200: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              message: { type: 'string', example: 'Password changed successfully' },
            },
          },
          401: { $ref: 'Error#' },
        },
      },
    },
    async (request: FastifyRequest<{ Body: ChangePasswordInput }>, reply: FastifyReply) => {
      const input = validate(changePasswordSchema, request.body);
      await authService.changePassword(
        request.user!.userId,
        input.currentPassword,
        input.newPassword
      );
      return reply.send({ success: true, message: 'Password changed successfully' });
    }
  );

  /**
   * Get current user info (requires authentication)
   */
  app.get(
    '/me',
    {
      preHandler: [authenticateUser],
      schema: {
        description: 'Get current authenticated user information',
        tags: ['auth'],
        security: [{ bearerAuth: [] }],
        response: {
          200: {
            type: 'object',
            properties: {
              success: { type: 'boolean', example: true },
              data: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  email: { type: 'string' },
                  firstName: { type: 'string' },
                  lastName: { type: 'string' },
                  role: { type: 'string' },
                  tenantId: { type: 'string' },
                  isActive: { type: 'boolean' },
                  lastLoginAt: { type: 'string', nullable: true },
                },
              },
            },
          },
          401: { $ref: 'Error#' },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const user = await prisma.user.findUnique({
        where: { id: request.user!.userId },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          tenantId: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
        },
      });

      return reply.send({ success: true, data: user });
    }
  );
}
