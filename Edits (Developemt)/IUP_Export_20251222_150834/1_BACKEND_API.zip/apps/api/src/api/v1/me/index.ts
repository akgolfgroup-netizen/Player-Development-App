import { FastifyPluginAsync } from 'fastify';
import { authenticationError } from '../../../core/errors';

const meRoutes: FastifyPluginAsync = async (fastify) => {
  fastify.get('/', {
    onRequest: [fastify.authenticate],
    handler: async (req, _reply) => {
      if (!req.user) {
        throw authenticationError();
      }

      return {
        id: req.user.id,
        email: req.user.email,
        firstName: req.user.firstName,
        lastName: req.user.lastName,
        role: req.user.role,
      };
    },
  });
};

export default meRoutes;
