/**
 * DataGolf Integration Service
 * Handles integration with DataGolf API and comparison functionality
 */

import { PrismaClient } from '@prisma/client';
import { NotFoundError } from '../../../middleware/errors';
import { getMapping, convertIupToDataGolf } from './mappings';
import type {
  DataGolfPlayerData,
  DataGolfTourAverages,
  IupToDataGolfComparison,
  DataGolfSyncStatus,
} from './types';

export class DataGolfService {
  constructor(private prisma: PrismaClient) {}

  /**
   * Get DataGolf data for a player
   */
  async getDataGolfPlayer(
    tenantId: string,
    playerId: string
  ): Promise<DataGolfPlayerData | null> {
    // Get player
    const player = await this.prisma.player.findFirst({
      where: {
        id: playerId,
        tenantId,
      },
    });

    if (!player) {
      throw new NotFoundError('Player not found');
    }

    // Get DataGolf player data
    const dataGolfPlayer = await this.prisma.dataGolfPlayer.findFirst({
      where: {
        iupPlayerId: playerId,
      },
    });

    if (!dataGolfPlayer) {
      return null;
    }

    return {
      playerId: dataGolfPlayer.iupPlayerId,
      dataGolfPlayerId: dataGolfPlayer.dataGolfId,
      playerName: dataGolfPlayer.playerName,
      tour: dataGolfPlayer.tour,
      lastUpdated: dataGolfPlayer.lastSynced,
      strokesGainedTotal: dataGolfPlayer.sgTotal ? Number(dataGolfPlayer.sgTotal) : null,
      strokesGainedOTT: dataGolfPlayer.sgOffTee ? Number(dataGolfPlayer.sgOffTee) : null,
      strokesGainedAPR: dataGolfPlayer.sgApproach ? Number(dataGolfPlayer.sgApproach) : null,
      strokesGainedARG: dataGolfPlayer.sgAroundGreen ? Number(dataGolfPlayer.sgAroundGreen) : null,
      strokesGainedPutting: dataGolfPlayer.sgPutting ? Number(dataGolfPlayer.sgPutting) : null,
      drivingDistance: dataGolfPlayer.drivingDistance ? Number(dataGolfPlayer.drivingDistance) : null,
      drivingAccuracy: dataGolfPlayer.drivingAccuracy ? Number(dataGolfPlayer.drivingAccuracy) : null,
      scoringAverage: null, // Not in schema
      birdiesToPars: null, // Not in schema
      greensInRegulation: dataGolfPlayer.girPercent ? Number(dataGolfPlayer.girPercent) : null,
      scrambling: dataGolfPlayer.scramblingPercent ? Number(dataGolfPlayer.scramblingPercent) : null,
      puttsPerRound: dataGolfPlayer.puttsPerRound ? Number(dataGolfPlayer.puttsPerRound) : null,
    };
  }

  /**
   * Get tour averages for a specific tour
   */
  async getTourAverages(tour: string, season: number): Promise<DataGolfTourAverages | null> {
    const tourAverage = await this.prisma.dataGolfTourAverage.findFirst({
      where: {
        tour,
        season,
      },
    });

    if (!tourAverage) {
      return null;
    }

    const stats = tourAverage.stats as any;
    return {
      tour: tourAverage.tour,
      season: tourAverage.season,
      lastUpdated: tourAverage.updatedAt,
      avgStrokesGainedTotal: stats?.avgSgTotal ?? null,
      avgStrokesGainedOTT: stats?.avgSgOtt ?? null,
      avgStrokesGainedAPR: stats?.avgSgApp ?? null,
      avgStrokesGainedARG: stats?.avgSgArg ?? null,
      avgStrokesGainedPutting: stats?.avgSgPutt ?? null,
      avgDrivingDistance: stats?.avgDrivingDistance ?? null,
      avgDrivingAccuracy: stats?.avgDrivingAccuracy ?? null,
      avgScoringAverage: stats?.avgScoringAverage ?? null,
      avgGreensInRegulation: stats?.avgGreensInRegulation ?? null,
      avgScrambling: stats?.avgScrambling ?? null,
      avgPuttsPerRound: stats?.avgPuttsPerRound ?? null,
    };
  }

  /**
   * Compare IUP player performance to DataGolf tour averages
   */
  async compareToTour(
    tenantId: string,
    playerId: string,
    tour: string = 'PGA',
    season: number = new Date().getFullYear()
  ): Promise<IupToDataGolfComparison> {
    // Get player
    const player = await this.prisma.player.findFirst({
      where: {
        id: playerId,
        tenantId,
      },
    });

    if (!player) {
      throw new NotFoundError('Player not found');
    }

    // Get player's latest test results
    const testResults = await this.prisma.testResult.findMany({
      where: {
        playerId,
      },
      include: {
        test: true,
      },
      orderBy: {
        testDate: 'desc',
      },
      distinct: ['testId'],
    });

    // Get tour averages
    const tourAverages = await this.getTourAverages(tour, season);

    if (!tourAverages) {
      throw new NotFoundError(`Tour averages not found for ${tour} ${season}`);
    }

    // Build comparisons
    const comparisons: any[] = [];
    let aboveTourAverage = 0;
    let belowTourAverage = 0;
    let nearTourAverage = 0;

    for (const result of testResults) {
      const mapping = getMapping(result.test.testNumber);
      if (!mapping || mapping.dataGolfMetric === 'none') {
        continue;
      }

      const iupValue = Number(result.value);
      const convertedValue = convertIupToDataGolf(result.test.testNumber, iupValue);

      if (convertedValue === null) {
        continue;
      }

      // Get tour average for this metric (placeholder - would need proper mapping)
      let tourAvg = 0;
      let dataGolfValue = 0;

      // Map to tour averages based on metric
      switch (mapping.dataGolfMetric) {
        case 'driving_distance':
          tourAvg = tourAverages.avgDrivingDistance ?? 0;
          dataGolfValue = convertedValue;
          break;
        case 'strokes_gained_approach':
          tourAvg = tourAverages.avgStrokesGainedAPR ?? 0;
          dataGolfValue = iupValue; // Would need proper conversion
          break;
        case 'strokes_gained_putting':
          tourAvg = tourAverages.avgStrokesGainedPutting ?? 0;
          dataGolfValue = iupValue; // Would need proper conversion
          break;
        case 'strokes_gained_around_green':
          tourAvg = tourAverages.avgStrokesGainedARG ?? 0;
          dataGolfValue = iupValue; // Would need proper conversion
          break;
        case 'scoring_average':
          tourAvg = tourAverages.avgScoringAverage ?? 0;
          dataGolfValue = iupValue;
          break;
        default:
          continue;
      }

      const gap = dataGolfValue - tourAvg;
      const gapPercentage = tourAvg !== 0 ? (gap / tourAvg) * 100 : 0;

      // Calculate percentile (simplified)
      const percentile = gap > 0 ? 60 : gap < 0 ? 40 : 50;

      if (Math.abs(gapPercentage) < 5) {
        nearTourAverage++;
      } else if (gap > 0) {
        aboveTourAverage++;
      } else {
        belowTourAverage++;
      }

      comparisons.push({
        iupTestNumber: result.test.testNumber,
        iupTestName: result.test.name,
        iupValue,
        dataGolfMetric: mapping.dataGolfMetric,
        dataGolfValue,
        tourAverage: tourAvg,
        percentileVsTour: percentile,
        gap: Math.round(gap * 100) / 100,
        gapPercentage: Math.round(gapPercentage * 10) / 10,
      });
    }

    const totalTests = comparisons.length;
    const overallPercentile =
      totalTests > 0
        ? Math.round(
            ((aboveTourAverage + nearTourAverage * 0.5) / totalTests) * 100
          )
        : 50;

    return {
      playerId: player.id,
      playerName: `${player.firstName} ${player.lastName}`,
      category: player.category,
      comparisons,
      overallAssessment: {
        totalTests,
        aboveTourAverage,
        belowTourAverage,
        nearTourAverage,
        overallPercentile,
      },
    };
  }

  /**
   * Sync DataGolf data (placeholder for future implementation)
   *
   * TODO: Implement actual DataGolf API integration
   * This would require:
   * 1. DataGolf API credentials
   * 2. HTTP client setup
   * 3. Data transformation logic
   * 4. Error handling and retry logic
   * 5. Rate limiting
   */
  async syncDataGolf(_tenantId: string): Promise<DataGolfSyncStatus> {
    // Placeholder implementation
    const now = new Date();
    const nextSync = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours

    return {
      lastSyncAt: now,
      nextSyncAt: nextSync,
      syncStatus: 'idle',
      playersUpdated: 0,
      tourAveragesUpdated: 0,
      errors: ['DataGolf API integration not yet implemented'],
    };
  }

  /**
   * Get sync status
   */
  async getSyncStatus(): Promise<DataGolfSyncStatus> {
    // Get last sync time from database
    const lastSync = await this.prisma.dataGolfPlayer.findFirst({
      orderBy: {
        lastSynced: 'desc',
      },
      select: {
        lastSynced: true,
      },
    });

    const lastSyncAt = lastSync?.lastSynced || new Date(0);
    const nextSyncAt = new Date(lastSyncAt.getTime() + 24 * 60 * 60 * 1000);

    const playerCount = await this.prisma.dataGolfPlayer.count();
    const tourAverageCount = await this.prisma.dataGolfTourAverage.count();

    return {
      lastSyncAt,
      nextSyncAt,
      syncStatus: 'idle',
      playersUpdated: playerCount,
      tourAveragesUpdated: tourAverageCount,
    };
  }
}
