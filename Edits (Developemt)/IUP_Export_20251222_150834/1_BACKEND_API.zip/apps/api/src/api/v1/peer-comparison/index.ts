/**
 * Peer Comparison API Module
 */

export { peerComparisonRoutes } from './routes';
export { PeerComparisonService } from './service';
