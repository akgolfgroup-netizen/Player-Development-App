/**
 * Coach Analytics API Module
 */

export { coachAnalyticsRoutes } from './routes';
export { CoachAnalyticsService } from './service';
