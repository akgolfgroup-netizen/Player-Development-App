/**
 * Filter System API Module
 */

export { filterRoutes } from './routes';
export { FilterService } from './service';
