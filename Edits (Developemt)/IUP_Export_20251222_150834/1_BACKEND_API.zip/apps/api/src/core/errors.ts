// Standard error types
export type ErrorType =
  | 'validation_error'
  | 'authentication_error'
  | 'authorization_error'
  | 'domain_violation'
  | 'system_failure';

export interface StandardError {
  type: ErrorType;
  message: string;
  details?: Record<string, any>;
}

export class AppError extends Error {
  constructor(
    public type: ErrorType,
    public message: string,
    public statusCode: number,
    public details?: Record<string, any>
  ) {
    super(message);
    this.name = 'AppError';
  }

  toJSON(): StandardError {
    return {
      type: this.type,
      message: this.message,
      details: this.details,
    };
  }
}

// Error factory functions
export const validationError = (message: string, details?: Record<string, any>) =>
  new AppError('validation_error', message, 400, details);

export const authenticationError = (message: string = 'Authentication required') =>
  new AppError('authentication_error', message, 401);

export const authorizationError = (message: string = 'Access denied') =>
  new AppError('authorization_error', message, 403);

export const domainViolation = (message: string, details?: Record<string, any>) =>
  new AppError('domain_violation', message, 422, details);

export const systemFailure = (message: string = 'System error occurred') =>
  new AppError('system_failure', message, 500);
