import { FastifyInstance, FastifyRequest } from 'fastify';
import rateLimit from '@fastify/rate-limit';
import Redis from 'ioredis';
import { config } from '../config';
import { logger } from '../utils/logger';

/**
 * Rate limit configurations for different endpoints
 */
export const RateLimitConfig = {
  // General API rate limit
  default: {
    max: 100,
    timeWindow: '1 minute',
  },
  // Auth endpoints (login, register) - stricter
  auth: {
    max: 5,
    timeWindow: '1 minute',
  },
  // Heavy endpoints (reports, exports)
  heavy: {
    max: 10,
    timeWindow: '1 minute',
  },
  // Write operations
  write: {
    max: 30,
    timeWindow: '1 minute',
  },
  // Search/query operations
  search: {
    max: 50,
    timeWindow: '1 minute',
  },
};

/**
 * Get user identifier for rate limiting
 * Uses authenticated user ID if available, falls back to IP
 */
function keyGenerator(request: FastifyRequest): string {
  const userId = (request as any).user?.id;
  if (userId) {
    return `user:${userId}`;
  }
  // Fallback to IP for unauthenticated requests
  return `ip:${request.ip}`;
}

/**
 * Custom error response for rate limit exceeded
 */
function errorResponseBuilder(
  _request: FastifyRequest,
  context: { max: number; ttl: number }
): { statusCode: number; error: string; message: string; retryAfter: number } {
  return {
    statusCode: 429,
    error: 'Too Many Requests',
    message: `Du har oversteget grensen på ${context.max} forespørsler. Prøv igjen om ${Math.ceil(context.ttl / 1000)} sekunder.`,
    retryAfter: Math.ceil(context.ttl / 1000),
  };
}

/**
 * Register rate limiting plugin
 */
export async function registerRateLimit(app: FastifyInstance): Promise<void> {
  let store;

  // Use Redis for rate limiting if available
  if (config.redis?.url) {
    try {
      const redis = new Redis(config.redis.url, {
        maxRetriesPerRequest: 1,
        lazyConnect: true,
      });
      await redis.connect();

      store = {
        get: async (key: string) => {
          const result = await redis.get(`ratelimit:${key}`);
          return result ? parseInt(result, 10) : 0;
        },
        increment: async (key: string, ttl: number) => {
          const pipeline = redis.pipeline();
          pipeline.incr(`ratelimit:${key}`);
          pipeline.pexpire(`ratelimit:${key}`, ttl);
          const results = await pipeline.exec();
          return (results?.[0]?.[1] as number) || 1;
        },
      };

      logger.info('Rate limiting using Redis store');
    } catch (error) {
      logger.warn({ error }, 'Redis not available, using in-memory rate limiting');
    }
  }

  await app.register(rateLimit, {
    global: true,
    max: RateLimitConfig.default.max,
    timeWindow: RateLimitConfig.default.timeWindow,
    keyGenerator,
    errorResponseBuilder,
    ...(store && { store }),
    // Custom hook to add rate limit headers
    addHeaders: {
      'x-ratelimit-limit': true,
      'x-ratelimit-remaining': true,
      'x-ratelimit-reset': true,
    },
    // Skip rate limiting for health checks
    allowList: (request: FastifyRequest) => {
      return request.url === '/health' || request.url === '/ws/stats';
    },
  });

  logger.info('Rate limiting plugin registered');
}

/**
 * Route-specific rate limit decorators
 */
export function authRateLimit() {
  return {
    config: {
      rateLimit: RateLimitConfig.auth,
    },
  };
}

export function heavyRateLimit() {
  return {
    config: {
      rateLimit: RateLimitConfig.heavy,
    },
  };
}

export function writeRateLimit() {
  return {
    config: {
      rateLimit: RateLimitConfig.write,
    },
  };
}

export function searchRateLimit() {
  return {
    config: {
      rateLimit: RateLimitConfig.search,
    },
  };
}

/**
 * Custom rate limit for specific routes
 */
export function customRateLimit(max: number, timeWindow: string) {
  return {
    config: {
      rateLimit: { max, timeWindow },
    },
  };
}

export default registerRateLimit;
