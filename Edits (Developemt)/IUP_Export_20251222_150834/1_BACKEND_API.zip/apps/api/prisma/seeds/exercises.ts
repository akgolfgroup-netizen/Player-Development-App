/**
 * Seed Exercises
 * Golf training exercises for the IUP system
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function seedExercises() {
  console.log('🏌️ Seeding exercises...');

  const tenant = await prisma.tenant.findFirst({
    where: { slug: 'ak-golf-academy' },
  });

  if (!tenant) {
    throw new Error('Tenant not found. Run demo-users seed first.');
  }

  const exercises = [
    // TEKNIKK - Driver
    {
      name: 'Driver Alignment Drill',
      description: 'Øvelse for å forbedre siktelinje og stance med driver. Bruk alignment sticks for å sikre korrekt posisjon.',
      purpose: 'Forbedre presisjon og konsistens fra tee',
      exerciseType: 'teknikk',
      learningPhases: ['L1', 'L2', 'L3'],
      settings: ['S1', 'S2', 'S3'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C', 'D'],
      periods: ['G', 'S'],
      repsOrTime: '20 slag',
      equipment: { required: ['driver', 'alignment sticks', 'tee'], optional: ['launch monitor'] },
      location: 'range',
      difficulty: 'medium',
      processCategory: 'golfslag',
      tags: ['driver', 'alignment', 'accuracy'],
    },
    {
      name: 'Speed Training - Overspeed',
      description: 'Svinge med lettere kølle eller speed stick for å øke svinghastighet. 5 sving med maks innsats.',
      purpose: 'Øke clubhead speed og bespeed',
      exerciseType: 'teknikk',
      learningPhases: ['L3', 'L4', 'L5'],
      settings: ['S4', 'S5', 'S6'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C'],
      periods: ['G', 'S'],
      repsOrTime: '3x5 sving',
      equipment: { required: ['speed sticks'], optional: ['radar'] },
      location: 'range',
      difficulty: 'hard',
      processCategory: 'fysisk',
      tags: ['speed', 'power', 'driver'],
    },
    // TEKNIKK - Jern
    {
      name: '9-Shot Drill',
      description: 'Slå 9 ulike skudd: lav/mid/høy med fade/straight/draw. Utvikler slagkontroll.',
      purpose: 'Mestre ulike skuddtyper og trajectory control',
      exerciseType: 'teknikk',
      learningPhases: ['L3', 'L4', 'L5'],
      settings: ['S5', 'S6', 'S7'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90'],
      categories: ['A', 'B'],
      periods: ['G', 'S', 'T'],
      repsOrTime: '27 slag (3 per type)',
      equipment: { required: ['7-iron'], optional: ['launch monitor'] },
      location: 'range',
      difficulty: 'hard',
      processCategory: 'teknikk',
      tags: ['shot shaping', 'iron play', 'control'],
    },
    {
      name: 'Distance Control Ladder',
      description: 'Slå wedge til ulike avstander: 50m, 60m, 70m, 80m. Fokus på konsistent lengdekontroll.',
      purpose: 'Forbedre avstandskontroll med wedger',
      exerciseType: 'teknikk',
      learningPhases: ['L2', 'L3', 'L4'],
      settings: ['S3', 'S4', 'S5'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80'],
      categories: ['A', 'B', 'C', 'D'],
      periods: ['G', 'S'],
      repsOrTime: '20 slag',
      equipment: { required: ['wedges', 'range balls'], optional: ['laser'] },
      location: 'range',
      difficulty: 'medium',
      processCategory: 'golfslag',
      tags: ['wedge', 'distance control', 'scoring'],
    },
    // SHORT GAME
    {
      name: 'Up and Down Challenge',
      description: 'Chip og putt fra 5 ulike posisjoner rundt green. Mål: få ballen i hullet på 2 slag eller mindre.',
      purpose: 'Forbedre short game under press',
      exerciseType: 'spill',
      learningPhases: ['L3', 'L4', 'L5'],
      settings: ['S5', 'S6', 'S7'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90'],
      categories: ['A', 'B', 'C'],
      periods: ['G', 'S', 'T'],
      repsOrTime: '10 forsøk',
      equipment: { required: ['wedges', 'putter', 'balls'] },
      location: 'short_game_area',
      difficulty: 'medium',
      processCategory: 'spill',
      tags: ['chipping', 'putting', 'scoring', 'pressure'],
    },
    {
      name: 'Bunker Splash Drill',
      description: 'Grunnleggende bunkerslag. Fokus på å treffe sanden 5cm bak ballen.',
      purpose: 'Mestre standard bunkerslag',
      exerciseType: 'teknikk',
      learningPhases: ['L1', 'L2', 'L3'],
      settings: ['S2', 'S3', 'S4'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80'],
      categories: ['B', 'C', 'D', 'E'],
      periods: ['G'],
      repsOrTime: '15 slag',
      equipment: { required: ['sand wedge', 'bunker'] },
      location: 'bunker',
      difficulty: 'medium',
      processCategory: 'teknikk',
      tags: ['bunker', 'sand play', 'short game'],
    },
    // PUTTING
    {
      name: 'Gate Putting Drill',
      description: 'Sett opp to tees som en port foran hullet. Putt gjennom porten fra økende avstander.',
      purpose: 'Forbedre putting accuracy og linje',
      exerciseType: 'teknikk',
      learningPhases: ['L1', 'L2', 'L3'],
      settings: ['S1', 'S2', 'S3'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C', 'D', 'E'],
      periods: ['G', 'S', 'T'],
      repsOrTime: '20 putter',
      equipment: { required: ['putter', 'balls', 'tees'] },
      location: 'putting_green',
      difficulty: 'easy',
      processCategory: 'teknikk',
      tags: ['putting', 'accuracy', 'fundamentals'],
    },
    {
      name: 'Lag Putting - 10m Circle',
      description: 'Putt fra 10m og prøv å få ballen innenfor en 1m sirkel rundt hullet. 10 forsøk.',
      purpose: 'Forbedre avstandskontroll på lange putter',
      exerciseType: 'teknikk',
      learningPhases: ['L2', 'L3', 'L4'],
      settings: ['S3', 'S4', 'S5'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90'],
      categories: ['A', 'B', 'C', 'D'],
      periods: ['G', 'S'],
      repsOrTime: '10 putter',
      equipment: { required: ['putter', 'balls'], optional: ['string line'] },
      location: 'putting_green',
      difficulty: 'medium',
      processCategory: 'teknikk',
      tags: ['putting', 'lag putting', 'distance control'],
    },
    {
      name: 'Pressure Putt Challenge',
      description: 'Må holle 5 putter på rad fra 1.5m for å "vinne". Start på nytt ved miss.',
      purpose: 'Bygge mental styrke og prestere under press',
      exerciseType: 'mental',
      learningPhases: ['L4', 'L5'],
      settings: ['S6', 'S7', 'S8'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B'],
      periods: ['S', 'T'],
      repsOrTime: 'Til fullført',
      equipment: { required: ['putter', 'balls'] },
      location: 'putting_green',
      difficulty: 'hard',
      processCategory: 'mental',
      tags: ['putting', 'pressure', 'mental', 'competition'],
    },
    // FYSISK TRENING
    {
      name: 'Golf Mobility Routine',
      description: 'Dynamisk tøyning for golf: hip circles, thoracic rotation, shoulder stretches. 10 reps hver.',
      purpose: 'Øke bevegelighet for bedre sving',
      exerciseType: 'fysisk',
      learningPhases: ['L1', 'L2', 'L3', 'L4', 'L5'],
      settings: ['S1', 'S2', 'S3'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C', 'D', 'E'],
      periods: ['G', 'S', 'T', 'E'],
      repsOrTime: '15 min',
      equipment: { required: [], optional: ['yoga mat', 'foam roller'] },
      location: 'gym',
      difficulty: 'easy',
      processCategory: 'fysisk',
      tags: ['mobility', 'warmup', 'flexibility'],
    },
    {
      name: 'Core Stability Circuit',
      description: 'Planke, side planke, dead bugs, bird dogs. 3 runder, 30 sek hver øvelse.',
      purpose: 'Styrke core for stabil sving',
      exerciseType: 'fysisk',
      learningPhases: ['L2', 'L3', 'L4'],
      settings: ['S3', 'S4', 'S5'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C', 'D'],
      periods: ['G', 'S'],
      repsOrTime: '15 min',
      equipment: { required: ['yoga mat'] },
      location: 'gym',
      difficulty: 'medium',
      processCategory: 'fysisk',
      tags: ['core', 'stability', 'strength'],
    },
    {
      name: 'Lower Body Power',
      description: 'Squats, lunges, box jumps, med ball rotational throws. Fokus på eksplosiv kraft.',
      purpose: 'Bygge kraft i underkropp for mer power',
      exerciseType: 'fysisk',
      learningPhases: ['L3', 'L4', 'L5'],
      settings: ['S5', 'S6', 'S7'],
      clubSpeedLevels: ['CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C'],
      periods: ['G'],
      repsOrTime: '30 min',
      equipment: { required: ['weights', 'med ball', 'box'] },
      location: 'gym',
      difficulty: 'hard',
      processCategory: 'fysisk',
      tags: ['strength', 'power', 'legs', 'explosiveness'],
    },
    // MENTAL TRENING
    {
      name: 'Pre-Shot Routine Practice',
      description: 'Øv på din pre-shot rutine. Samme prosess for hvert slag: visualisering, setup, sving.',
      purpose: 'Automatisere pre-shot rutine for konsistens',
      exerciseType: 'mental',
      learningPhases: ['L2', 'L3', 'L4', 'L5'],
      settings: ['S4', 'S5', 'S6'],
      clubSpeedLevels: ['CS60', 'CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C', 'D'],
      periods: ['G', 'S', 'T'],
      repsOrTime: '15 slag',
      equipment: { required: ['any club'] },
      location: 'range',
      difficulty: 'medium',
      processCategory: 'mental',
      tags: ['mental', 'routine', 'focus', 'consistency'],
    },
    {
      name: 'Visualization Session',
      description: '10 min visualisering: Se for deg perfekte slag, hole-outs, og konkurransesituasjoner.',
      purpose: 'Styrke mental forestillingsevne',
      exerciseType: 'mental',
      learningPhases: ['L3', 'L4', 'L5'],
      settings: ['S5', 'S6', 'S7'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C'],
      periods: ['S', 'T'],
      repsOrTime: '10 min',
      equipment: { required: [] },
      location: 'anywhere',
      difficulty: 'medium',
      processCategory: 'mental',
      tags: ['mental', 'visualization', 'imagery'],
    },
    // SPILL PÅ BANE
    {
      name: '9-Hole Playing Lesson',
      description: 'Spill 9 hull med fokus på course management og strategi. Noter beslutninger.',
      purpose: 'Utvikle baneforståelse og strategi',
      exerciseType: 'spill',
      learningPhases: ['L4', 'L5'],
      settings: ['S7', 'S8', 'S9'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90', 'CS100'],
      categories: ['A', 'B', 'C'],
      periods: ['S', 'T'],
      repsOrTime: '2 timer',
      equipment: { required: ['full bag'] },
      location: 'course',
      difficulty: 'hard',
      processCategory: 'spill',
      tags: ['course management', 'strategy', 'on-course'],
    },
    {
      name: 'Worst Ball Scramble',
      description: 'Spill med 2 baller. Spill alltid fra den dårligste posisjonen. Bygger mental styrke.',
      purpose: 'Trene på vanskelige situasjoner og recovery',
      exerciseType: 'spill',
      learningPhases: ['L4', 'L5'],
      settings: ['S7', 'S8'],
      clubSpeedLevels: ['CS70', 'CS80', 'CS90'],
      categories: ['A', 'B'],
      periods: ['G', 'S'],
      repsOrTime: '9 hull',
      equipment: { required: ['full bag', 'extra balls'] },
      location: 'course',
      difficulty: 'hard',
      processCategory: 'spill',
      tags: ['mental', 'recovery', 'challenge', 'on-course'],
    },
  ];

  let created = 0;
  let skipped = 0;

  for (const exercise of exercises) {
    const existing = await prisma.exercise.findFirst({
      where: {
        tenantId: tenant.id,
        name: exercise.name,
      },
    });

    if (!existing) {
      await prisma.exercise.create({
        data: {
          tenantId: tenant.id,
          ...exercise,
        },
      });
      created++;
    } else {
      skipped++;
    }
  }

  console.log(`   ✅ Created ${created} exercises (${skipped} already existed)`);
}
