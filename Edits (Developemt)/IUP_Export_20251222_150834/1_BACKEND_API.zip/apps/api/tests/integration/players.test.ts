import { FastifyInstance } from 'fastify';
import { buildApp } from '../../src/app';
import { getPrismaClient } from '../../src/core/db/prisma';

describe('Players API Integration Tests', () => {
  let app: FastifyInstance;
  let prisma: ReturnType<typeof getPrismaClient>;
  let accessToken: string;
  let tenantId: string;
  let userId: string;
  let coachId: string;
  let playerId: string;

  beforeAll(async () => {
    try {
      app = await buildApp({ logger: false });
      prisma = getPrismaClient();
      await app.ready();
    } catch (error) {
      console.error('Error in beforeAll:', error);
      throw error;
    }

    // Register a test user and get token
    const registerResponse = await app.inject({
      method: 'POST',
      url: '/api/v1/auth/register',
      payload: {
        email: 'coach@test.com',
        password: 'TestPassword123!',
        firstName: 'Test',
        lastName: 'Coach',
        organizationName: 'Test Academy',
        role: 'admin',
      },
    });

    const registerBody = JSON.parse(registerResponse.body);
    accessToken = registerBody.data.accessToken;
    userId = registerBody.data.user.id;
    tenantId = registerBody.data.user.tenantId;

    // Create a coach for player assignment
    const coachResponse = await app.inject({
      method: 'POST',
      url: '/api/v1/coaches',
      headers: { authorization: `Bearer ${accessToken}` },
      payload: {
        firstName: 'John',
        lastName: 'Doe',
        email: 'john.doe@coach.com',
        specializations: ['putting', 'driving'],
        status: 'active',
      },
    });

    const coachBody = JSON.parse(coachResponse.body);
    coachId = coachBody.data.id;
  });

  afterAll(async () => {
    // Clean up
    if (prisma) {
      if (playerId) {
        await prisma.player.delete({ where: { id: playerId } }).catch(() => {});
      }
      if (coachId) {
        await prisma.coach.delete({ where: { id: coachId } }).catch(() => {});
      }
      if (userId) {
        await prisma.refreshToken.deleteMany({ where: { userId } });
        await prisma.user.delete({ where: { id: userId } }).catch(() => {});
      }
      if (tenantId) {
        await prisma.tenant.delete({ where: { id: tenantId } }).catch(() => {});
      }
      await prisma.$disconnect();
    }

    if (app) {
      await app.close();
    }
  });

  describe('POST /api/v1/players', () => {
    it('should create a new player', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/players',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          firstName: 'Alice',
          lastName: 'Smith',
          email: 'alice@example.com',
          dateOfBirth: '2005-03-15',
          gender: 'female',
          category: 'C',
          coachId: coachId,
          currentPeriod: 'G',
          status: 'active',
        },
      });

      expect(response.statusCode).toBe(201);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data).toHaveProperty('id');
      expect(body.data.firstName).toBe('Alice');
      expect(body.data.lastName).toBe('Smith');
      expect(body.data.category).toBe('C');
      expect(body.data.coachId).toBe(coachId);

      playerId = body.data.id;
    });

    it('should reject duplicate email', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/players',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          firstName: 'Alice',
          lastName: 'Duplicate',
          email: 'alice@example.com',
          dateOfBirth: '2005-03-15',
          gender: 'female',
          category: 'C',
        },
      });

      expect(response.statusCode).toBe(409);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(false);
      expect(body.error.code).toBe('CONFLICT');
    });

    it('should validate required fields', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/players',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          firstName: 'Bob',
          // Missing required fields
        },
      });

      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(false);
      expect(body.error.code).toBe('VALIDATION_ERROR');
    });

    it('should reject invalid coach ID', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/players',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          firstName: 'Bob',
          lastName: 'Test',
          email: 'bob@example.com',
          dateOfBirth: '2005-03-15',
          gender: 'male',
          category: 'C',
          coachId: '00000000-0000-0000-0000-000000000000',
        },
      });

      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.body);
      expect(body.error.message).toContain('Coach not found');
    });
  });

  describe('GET /api/v1/players', () => {
    it('should list players with pagination', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players?page=1&limit=10',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.players).toBeInstanceOf(Array);
      expect(body.data.pagination).toHaveProperty('page', 1);
      expect(body.data.pagination).toHaveProperty('limit', 10);
      expect(body.data.pagination).toHaveProperty('total');
      expect(body.data.pagination).toHaveProperty('totalPages');
    });

    it('should filter players by category', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players?category=C',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      body.data.players.forEach((player: any) => {
        expect(player.category).toBe('C');
      });
    });

    it('should search players by name', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players?search=Alice',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.players.length).toBeGreaterThan(0);
    });

    it('should filter by coach ID', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/players?coachId=${coachId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      body.data.players.forEach((player: any) => {
        expect(player.coach.id).toBe(coachId);
      });
    });
  });

  describe('GET /api/v1/players/:id', () => {
    it('should get player by ID', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/players/${playerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.id).toBe(playerId);
      expect(body.data.firstName).toBe('Alice');
      expect(body.data).toHaveProperty('coach');
    });

    it('should return 404 for non-existent player', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players/00000000-0000-0000-0000-000000000000',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(404);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(false);
      expect(body.error.code).toBe('NOT_FOUND');
    });
  });

  describe('PATCH /api/v1/players/:id', () => {
    it('should update player', async () => {
      const response = await app.inject({
        method: 'PATCH',
        url: `/api/v1/players/${playerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          category: 'D',
          handicap: 5.5,
          status: 'active',
        },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.category).toBe('D');
      expect(body.data.handicap).toBe('5.5');
    });

    it('should return 404 for non-existent player', async () => {
      const response = await app.inject({
        method: 'PATCH',
        url: '/api/v1/players/00000000-0000-0000-0000-000000000000',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          category: 'E',
        },
      });

      expect(response.statusCode).toBe(404);
    });
  });

  describe('GET /api/v1/players/:id/weekly-summary', () => {
    it('should get player weekly summary', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/players/${playerId}/weekly-summary`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data).toHaveProperty('player');
      expect(body.data).toHaveProperty('week');
      expect(body.data).toHaveProperty('training');
      expect(body.data).toHaveProperty('tests');
      expect(body.data).toHaveProperty('breakingPoints');
      expect(body.data.player.id).toBe(playerId);
    });

    it('should accept custom week start date', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/players/${playerId}/weekly-summary?weekStart=2024-01-01`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.week.start).toBe('2024-01-01');
    });
  });

  describe('DELETE /api/v1/players/:id', () => {
    it('should delete player', async () => {
      // Create a player to delete
      const createResponse = await app.inject({
        method: 'POST',
        url: '/api/v1/players',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          firstName: 'ToDelete',
          lastName: 'Player',
          email: 'delete@example.com',
          dateOfBirth: '2005-03-15',
          gender: 'male',
          category: 'C',
        },
      });

      const createBody = JSON.parse(createResponse.body);
      const deletePlayerId = createBody.data.id;

      const deleteResponse = await app.inject({
        method: 'DELETE',
        url: `/api/v1/players/${deletePlayerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(deleteResponse.statusCode).toBe(200);

      const deleteBody = JSON.parse(deleteResponse.body);
      expect(deleteBody.success).toBe(true);

      // Verify player is deleted
      const getResponse = await app.inject({
        method: 'GET',
        url: `/api/v1/players/${deletePlayerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(getResponse.statusCode).toBe(404);
    });
  });

  describe('Authentication', () => {
    it('should reject requests without token', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players',
      });

      expect(response.statusCode).toBe(401);
    });

    it('should reject requests with invalid token', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/players',
        headers: { authorization: 'Bearer invalid-token' },
      });

      expect(response.statusCode).toBe(401);
    });
  });
});
