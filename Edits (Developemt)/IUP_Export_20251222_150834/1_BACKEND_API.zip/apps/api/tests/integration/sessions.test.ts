import { FastifyInstance } from 'fastify';
import { buildApp } from '../../src/app';
import { getPrismaClient } from '../../src/core/db/prisma';

describe('Sessions API Integration Tests', () => {
  let app: FastifyInstance;
  let prisma: ReturnType<typeof getPrismaClient>;
  let accessToken: string;
  let tenantId: string;
  let userId: string;
  let playerId: string;
  let sessionId: string;

  beforeAll(async () => {
    app = await buildApp({ logger: false });
    prisma = getPrismaClient();
    await app.ready();

    // Register a test user (coach)
    const registerResponse = await app.inject({
      method: 'POST',
      url: '/api/v1/auth/register',
      payload: {
        email: 'coach@sessiontest.com',
        password: 'TestPassword123!',
        firstName: 'Session',
        lastName: 'Coach',
        organizationName: 'Session Test Academy',
        role: 'coach',
      },
    });

    const registerBody = JSON.parse(registerResponse.body);
    accessToken = registerBody.data.accessToken;
    userId = registerBody.data.user.id;
    tenantId = registerBody.data.user.tenantId;

    // Create a test player
    const playerResponse = await app.inject({
      method: 'POST',
      url: '/api/v1/players',
      headers: { authorization: `Bearer ${accessToken}` },
      payload: {
        firstName: 'Test',
        lastName: 'Player',
        email: 'player@sessiontest.com',
        dateOfBirth: '2010-05-15',
        gender: 'male',
        category: 'B',
      },
    });

    const playerBody = JSON.parse(playerResponse.body);
    playerId = playerBody.data.id;
  });

  afterAll(async () => {
    // Clean up
    if (sessionId) {
      await prisma.trainingSession.delete({ where: { id: sessionId } }).catch(() => {});
    }
    if (playerId) {
      await prisma.player.delete({ where: { id: playerId } }).catch(() => {});
    }
    if (userId) {
      await prisma.refreshToken.deleteMany({ where: { userId } });
      await prisma.user.delete({ where: { id: userId } }).catch(() => {});
    }
    if (tenantId) {
      await prisma.tenant.delete({ where: { id: tenantId } }).catch(() => {});
    }

    await app.close();
    await prisma.$disconnect();
  });

  describe('POST /api/v1/sessions', () => {
    it('should create a new session', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/sessions',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          playerId,
          sessionType: 'individual',
          scheduledDate: new Date().toISOString(),
          durationMinutes: 60,
          focus: 'putting',
          notes: 'Focus on lag putts',
        },
      });

      expect(response.statusCode).toBe(201);

      const body = JSON.parse(response.body);
      expect(body).toHaveProperty('id');
      expect(body.playerId).toBe(playerId);
      expect(body.sessionType).toBe('individual');
      expect(body.durationMinutes).toBe(60);

      sessionId = body.id;
    });

    it('should validate required fields', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/sessions',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          // Missing required fields
          sessionType: 'individual',
        },
      });

      expect(response.statusCode).toBe(400);
    });
  });

  describe('GET /api/v1/sessions', () => {
    it('should list sessions with pagination', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/sessions?page=1&limit=10',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.sessions).toBeInstanceOf(Array);
      expect(body.pagination).toHaveProperty('page', 1);
      expect(body.pagination).toHaveProperty('limit', 10);
    });

    it('should filter by player', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/sessions?playerId=${playerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.sessions.length).toBeGreaterThan(0);
      body.sessions.forEach((session: any) => {
        expect(session.playerId).toBe(playerId);
      });
    });

    it('should filter by status', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/sessions?status=planned',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);
    });
  });

  describe('GET /api/v1/sessions/technical-cues', () => {
    it('should return predefined technical cues', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/sessions/technical-cues',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body).toBeInstanceOf(Array);
      expect(body.length).toBeGreaterThan(0);
    });
  });

  describe('GET /api/v1/sessions/:id', () => {
    it('should get session by ID', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/sessions/${sessionId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.id).toBe(sessionId);
      expect(body.playerId).toBe(playerId);
    });

    it('should return 404 for non-existent session', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/sessions/00000000-0000-0000-0000-000000000000',
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(404);
    });
  });

  describe('PATCH /api/v1/sessions/:id', () => {
    it('should update session', async () => {
      const response = await app.inject({
        method: 'PATCH',
        url: `/api/v1/sessions/${sessionId}`,
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          durationMinutes: 90,
          notes: 'Extended session - added short game practice',
        },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.durationMinutes).toBe(90);
    });
  });

  describe('PATCH /api/v1/sessions/:id/evaluation', () => {
    it('should update session evaluation', async () => {
      const response = await app.inject({
        method: 'PATCH',
        url: `/api/v1/sessions/${sessionId}/evaluation`,
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          focusRating: 8,
          energyLevel: 7,
          techniqueNotes: 'Good progress on putting stroke',
          preShotRoutineCompleted: true,
          technicalCues: ['Hold armen rett', 'Fokuser på tempo'],
        },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.focusRating).toBe(8);
      expect(body.energyLevel).toBe(7);
    });
  });

  describe('POST /api/v1/sessions/:id/complete', () => {
    it('should complete session with evaluation', async () => {
      const response = await app.inject({
        method: 'POST',
        url: `/api/v1/sessions/${sessionId}/complete`,
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          overallRating: 8,
          achievements: ['Completed 50 putts from 2m'],
          notes: 'Great progress today',
        },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.status).toBe('completed');
    });
  });

  describe('GET /api/v1/sessions/stats/evaluation', () => {
    it('should get evaluation statistics', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/sessions/stats/evaluation?playerId=${playerId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body).toHaveProperty('totalSessions');
      expect(body).toHaveProperty('averages');
    });

    it('should filter by date range', async () => {
      const fromDate = new Date();
      fromDate.setMonth(fromDate.getMonth() - 1);

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/sessions/stats/evaluation?playerId=${playerId}&fromDate=${fromDate.toISOString()}&toDate=${new Date().toISOString()}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(response.statusCode).toBe(200);
    });
  });

  describe('DELETE /api/v1/sessions/:id', () => {
    it('should delete session', async () => {
      // Create a session to delete
      const createResponse = await app.inject({
        method: 'POST',
        url: '/api/v1/sessions',
        headers: { authorization: `Bearer ${accessToken}` },
        payload: {
          playerId,
          sessionType: 'individual',
          scheduledDate: new Date().toISOString(),
          durationMinutes: 30,
          focus: 'driving',
        },
      });

      const createBody = JSON.parse(createResponse.body);
      const deleteSessionId = createBody.id;

      const deleteResponse = await app.inject({
        method: 'DELETE',
        url: `/api/v1/sessions/${deleteSessionId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(deleteResponse.statusCode).toBe(200);

      const deleteBody = JSON.parse(deleteResponse.body);
      expect(deleteBody.success).toBe(true);

      // Verify session is deleted
      const getResponse = await app.inject({
        method: 'GET',
        url: `/api/v1/sessions/${deleteSessionId}`,
        headers: { authorization: `Bearer ${accessToken}` },
      });

      expect(getResponse.statusCode).toBe(404);
    });
  });
});
