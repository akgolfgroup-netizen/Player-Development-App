# AK Golf Academy - IUP Platform

> Individual Development Plan (IUP) platform for junior golfers

[![Status](https://img.shields.io/badge/Status-Production-success)]()
[![Version](https://img.shields.io/badge/Version-1.0.0-blue)]()
[![Node](https://img.shields.io/badge/Node-20+-green)]()

---

## Overview

Professional coaching platform for AK Golf Academy featuring:

- **Individual Development Plans** - Track progress for categories A-K
- **20+ Test Protocols** - Driver, approach, short game, putting, physical
- **Analytics & Insights** - Peer comparison, breaking point detection
- **Training Plans** - Periodization with E/G/S/T phases
- **Booking System** - Coach availability and session management

---

## Quick Start

### Prerequisites

- Node.js 20+
- Docker Desktop
- pnpm (`npm install -g pnpm`)

### Setup (5 minutes)

```bash
# 1. Start infrastructure
cd apps/api
docker-compose up -d

# 2. Setup database
pnpm install
npx prisma generate
npx prisma migrate deploy
pnpm run prisma:seed

# 3. Start backend
pnpm dev
# http://localhost:3000

# 4. Start frontend (new terminal)
cd ../web
pnpm install
pnpm start
# http://localhost:3001
```

### Demo Login

| Role   | Email            | Password  |
|--------|------------------|-----------|
| Admin  | admin@demo.com   | admin123  |
| Coach  | coach@demo.com   | coach123  |
| Player | player@demo.com  | player123 |

---

## Project Structure

```
IUP_Master_V1/
├── apps/
│   ├── api/              # Fastify backend (40+ endpoints)
│   ├── web/              # React frontend
│   └── golfer/           # Mobile app (Ionic/Capacitor)
│
├── packages/
│   ├── database/         # Shared Prisma schema
│   └── design-system/    # UI components & tokens
│
├── docs/                 # Documentation
│   ├── features/         # Feature-specific docs
│   ├── api/              # API documentation
│   ├── mockups/          # UI mockups
│   └── archive/          # Historical docs
│
├── scripts/              # Utility scripts
│   ├── migrations/       # Database migrations
│   └── testing/          # Test scripts
│
├── config/               # Infrastructure config
└── data/                 # Reference data
```

---

## Technology Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Frontend   | React 18, React Router 7, Axios   |
| Backend    | Fastify 4, Prisma 5, Zod          |
| Database   | PostgreSQL 16, Redis 7            |
| Auth       | JWT, Argon2                       |
| Design     | Inter font, Blue Palette 01       |
| Build      | pnpm, Turbo, Docker               |

---

## Documentation

| Document | Description |
|----------|-------------|
| [Documentation Index](./docs/README.md) | Complete documentation overview |
| [API Reference](./docs/API_REFERENCE_COMPLETE.md) | Full API documentation |
| [Design System](./docs/features/design-system/DESIGN_SYSTEM.md) | UI/UX guidelines |
| [Architecture](./docs/architecture/) | System architecture |

### Feature Documentation

- [DataGolf Integration](./docs/features/datagolf/)
- [OAuth Implementation](./docs/features/oauth/)
- [Subscription System](./docs/features/subscription/)

---

## Development

### Running Tests

```bash
# Backend tests
cd apps/api && pnpm test

# Frontend tests
cd apps/web && pnpm test

# E2E tests
pnpm test:e2e
```

### Database Operations

```bash
# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# Open Prisma Studio
npx prisma studio

# Seed database
pnpm run prisma:seed
```

---

## API Endpoints

**Base URL**: `http://localhost:3000/api/v1`

| Endpoint | Description |
|----------|-------------|
| `POST /auth/login` | User authentication |
| `GET /players` | List players |
| `GET /tests` | List test protocols |
| `POST /tests/results/enhanced` | Record test result |
| `GET /coach-analytics/dashboard/:id` | Coach dashboard |
| `GET /peer-comparison` | Peer rankings |

See [API Documentation](./docs/API_REFERENCE_COMPLETE.md) for complete reference.

---

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

### Code Standards

- TypeScript for backend
- ESLint + Prettier formatting
- Conventional commits
- PR reviews required

---

## License

Proprietary - AK Golf Academy
© 2025 All Rights Reserved

---

**Built for Norwegian junior golfers following Team Norway IUP methodology**
