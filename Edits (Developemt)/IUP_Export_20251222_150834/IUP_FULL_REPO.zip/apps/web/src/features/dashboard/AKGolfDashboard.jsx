import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock, MapPin, Trophy, Target, CheckCircle2,
  MessageCircle, Award, Flame, TrendingUp, ChevronRight,
  Play, Bell, Users, Star, Calendar, Info, AlertCircle, RefreshCw
} from 'lucide-react';
import DagensPlan from '../../components/dashboard/DagensPlan';
import { useDashboard } from '../../hooks/useDashboard';
import SessionEvaluationWidget from '../sessions/SessionEvaluationWidget';

// ===== SKELETON COMPONENTS =====

const SkeletonPulse = ({ className = '' }) => (
  <div className={`animate-pulse bg-ak-mist rounded ${className}`} />
);

const CardSkeleton = ({ children }) => (
  <div className="bg-white rounded-xl border border-ak-mist p-5" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
    {children}
  </div>
);

const StatsSkeleton = () => (
  <CardSkeleton>
    <SkeletonPulse className="h-5 w-32 mb-4" />
    <div className="grid grid-cols-3 gap-4 mb-4">
      {[1, 2, 3].map(i => (
        <div key={i} className="text-center p-3 bg-ak-snow rounded-xl">
          <SkeletonPulse className="h-8 w-12 mx-auto mb-2" />
          <SkeletonPulse className="h-3 w-16 mx-auto" />
        </div>
      ))}
    </div>
    <div className="space-y-3">
      <SkeletonPulse className="h-2 w-full rounded-full" />
      <SkeletonPulse className="h-2 w-full rounded-full" />
    </div>
  </CardSkeleton>
);

const TasksSkeleton = () => (
  <CardSkeleton>
    <SkeletonPulse className="h-5 w-28 mb-4" />
    <div className="space-y-2">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="flex items-center gap-3 p-3 bg-ak-snow rounded-lg">
          <SkeletonPulse className="h-5 w-5 rounded-full" />
          <div className="flex-1">
            <SkeletonPulse className="h-4 w-3/4 mb-1" />
            <SkeletonPulse className="h-3 w-16" />
          </div>
        </div>
      ))}
    </div>
  </CardSkeleton>
);

const CountdownSkeleton = () => (
  <CardSkeleton>
    <div className="flex items-start gap-3">
      <SkeletonPulse className="h-10 w-10 rounded-lg" />
      <div className="flex-1">
        <SkeletonPulse className="h-3 w-20 mb-2" />
        <SkeletonPulse className="h-4 w-32 mb-1" />
        <SkeletonPulse className="h-3 w-24" />
      </div>
      <div className="text-right">
        <SkeletonPulse className="h-8 w-10 mb-1" />
        <SkeletonPulse className="h-3 w-8" />
      </div>
    </div>
  </CardSkeleton>
);

// ===== ERROR COMPONENT =====

const ErrorState = ({ message, onRetry }) => (
  <div className="bg-ak-error/10 border border-ak-error/20 rounded-xl p-6 text-center">
    <AlertCircle size={32} className="text-ak-error mx-auto mb-3" />
    <p className="text-[14px] text-ak-charcoal font-medium mb-2">Noe gikk galt</p>
    <p className="text-[13px] text-ak-steel mb-4">{message}</p>
    {onRetry && (
      <button
        onClick={onRetry}
        className="inline-flex items-center gap-2 px-4 py-2 bg-ak-primary text-white rounded-lg text-[13px] font-medium hover:bg-ak-primary-light transition-colors"
      >
        <RefreshCw size={14} />
        Prøv igjen
      </button>
    )}
  </div>
);

// ===== DASHBOARD WIDGETS =====

// Card wrapper component
const Card = ({ children, className = '', onClick }) => (
  <div
    className={`bg-white rounded-xl border border-ak-mist ${onClick ? 'cursor-pointer hover:border-ak-primary/30 transition-all' : ''} ${className}`}
    style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}
    onClick={onClick}
  >
    {children}
  </div>
);

// Widget Header
const WidgetHeader = ({ title, action, actionLabel = 'Se alle', icon: Icon }) => (
  <div className="flex items-center justify-between mb-4">
    <div className="flex items-center gap-2">
      {Icon && <Icon size={18} className="text-ak-primary" />}
      <h3 className="text-[15px] font-semibold text-ak-charcoal">{title}</h3>
    </div>
    {action && (
      <button
        onClick={action}
        className="text-[13px] text-ak-primary font-medium hover:underline flex items-center gap-1"
      >
        {actionLabel} <ChevronRight size={14} />
      </button>
    )}
  </div>
);

// ===== COUNTDOWN WIDGET =====
const CountdownWidget = ({ title, date, type, location }) => {
  const targetDate = new Date(date);
  const today = new Date();
  const diffTime = targetDate - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const getIcon = () => {
    switch (type) {
      case 'tournament': return <Trophy size={20} className="text-ak-gold" />;
      case 'test': return <Target size={20} className="text-ak-primary" />;
      default: return <Calendar size={20} className="text-ak-primary" />;
    }
  };

  const getBgColor = () => {
    switch (type) {
      case 'tournament': return 'bg-gradient-to-br from-ak-gold/10 to-ak-gold/5';
      case 'test': return 'bg-gradient-to-br from-ak-primary/10 to-ak-primary/5';
      default: return 'bg-ak-snow';
    }
  };

  return (
    <div className={`p-4 rounded-xl ${getBgColor()}`}>
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center shadow-sm">
          {getIcon()}
        </div>
        <div className="flex-1">
          <p className="text-[11px] font-medium text-ak-steel uppercase tracking-wide">
            {type === 'tournament' ? 'Neste turnering' : 'Neste test'}
          </p>
          <p className="text-[14px] font-semibold text-ak-charcoal mt-0.5">{title}</p>
          {location && (
            <p className="text-[12px] text-ak-steel flex items-center gap-1 mt-1">
              <MapPin size={12} /> {location}
            </p>
          )}
        </div>
        <div className="text-right">
          <p className="text-[28px] font-bold text-ak-primary">{diffDays}</p>
          <p className="text-[11px] text-ak-steel">dager</p>
        </div>
      </div>
    </div>
  );
};

// ===== TRAINING STATS WIDGET =====
const TrainingStatsWidget = ({ stats, onViewAll }) => {
  const { sessionsCompleted, sessionsTotal, hoursThisWeek, hoursGoal, streak } = stats;
  const sessionProgress = (sessionsCompleted / sessionsTotal) * 100;
  const hoursProgress = (hoursThisWeek / hoursGoal) * 100;

  return (
    <Card className="p-5">
      <WidgetHeader title="Treningsstatistikk" icon={TrendingUp} action={onViewAll} />

      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="text-center p-3 bg-ak-snow rounded-xl">
          <p className="text-[24px] font-bold text-ak-primary">{sessionsCompleted}</p>
          <p className="text-[11px] text-ak-steel">Økter fullført</p>
        </div>
        <div className="text-center p-3 bg-ak-snow rounded-xl">
          <p className="text-[24px] font-bold text-ak-primary">{hoursThisWeek}t</p>
          <p className="text-[11px] text-ak-steel">Timer denne uke</p>
        </div>
        <div className="text-center p-3 bg-gradient-to-br from-ak-gold/10 to-ak-gold/5 rounded-xl">
          <div className="flex items-center justify-center gap-1">
            <Flame size={18} className="text-ak-gold" />
            <p className="text-[24px] font-bold text-ak-gold">{streak}</p>
          </div>
          <p className="text-[11px] text-ak-steel">Dager i strekk</p>
        </div>
      </div>

      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-[12px] mb-1">
            <span className="text-ak-steel">Ukentlige økter</span>
            <span className="font-medium text-ak-charcoal">{sessionsCompleted}/{sessionsTotal}</span>
          </div>
          <div className="h-2 bg-ak-mist rounded-full overflow-hidden">
            <div
              className="h-full bg-ak-primary rounded-full transition-all duration-500"
              style={{ width: `${Math.min(sessionProgress, 100)}%` }}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-[12px] mb-1">
            <span className="text-ak-steel">Timer denne uke</span>
            <span className="font-medium text-ak-charcoal">{hoursThisWeek}/{hoursGoal}t</span>
          </div>
          <div className="h-2 bg-ak-mist rounded-full overflow-hidden">
            <div
              className="h-full bg-ak-primary-light rounded-full transition-all duration-500"
              style={{ width: `${Math.min(hoursProgress, 100)}%` }}
            />
          </div>
        </div>
      </div>
    </Card>
  );
};

// ===== TASKS WIDGET =====
const TasksWidget = ({ tasks, onToggle, onViewAll }) => {
  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <Card className="p-5">
      <WidgetHeader
        title="Mine oppgaver"
        icon={CheckCircle2}
        action={onViewAll}
        actionLabel={`${completedCount}/${tasks.length} fullført`}
      />

      <div className="space-y-2">
        {tasks.map(task => (
          <div
            key={task.id}
            className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all ${
              task.completed ? 'bg-ak-success/10' : 'bg-ak-snow hover:bg-ak-mist'
            }`}
            onClick={() => onToggle(task.id)}
          >
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
              task.completed
                ? 'bg-ak-success border-ak-success'
                : 'border-ak-mist hover:border-ak-primary'
            }`}>
              {task.completed && (
                <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              )}
            </div>
            <div className="flex-1">
              <p className={`text-[14px] ${task.completed ? 'text-ak-steel line-through' : 'text-ak-charcoal'}`}>
                {task.title}
              </p>
              <p className="text-[11px] text-ak-steel">{task.area}</p>
            </div>
            {task.priority === 'high' && !task.completed && (
              <span className="px-2 py-0.5 bg-ak-error/10 text-ak-error text-[10px] font-medium rounded-full">
                Viktig
              </span>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== MESSAGES WIDGET =====
const MessagesWidget = ({ messages, onViewAll }) => {
  const unreadCount = messages.filter(m => !m.read).length;

  return (
    <Card className="p-5">
      <WidgetHeader
        title="Beskjeder"
        icon={MessageCircle}
        action={onViewAll}
      />

      {unreadCount > 0 && (
        <div className="flex items-center gap-2 mb-3 p-2 bg-ak-primary/5 rounded-lg">
          <Bell size={14} className="text-ak-primary" />
          <span className="text-[12px] text-ak-primary font-medium">{unreadCount} uleste beskjeder</span>
        </div>
      )}

      <div className="space-y-2">
        {messages.slice(0, 4).map(msg => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-all ${
              msg.read ? 'bg-ak-snow' : 'bg-ak-primary/5 hover:bg-ak-primary/10'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-ak-primary flex items-center justify-center text-white text-[12px] font-medium">
              {msg.from.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className={`text-[13px] truncate ${msg.read ? 'text-ak-steel' : 'text-ak-charcoal font-medium'}`}>
                  {msg.from}
                </p>
                {msg.isGroup && <Users size={12} className="text-ak-steel" />}
              </div>
              <p className="text-[12px] text-ak-steel truncate">{msg.preview}</p>
            </div>
            <span className="text-[10px] text-ak-steel whitespace-nowrap">{msg.time}</span>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== GAMIFICATION WIDGET =====
const GamificationWidget = ({ achievements, xp, level, nextLevelXp, onViewAll }) => {
  const xpProgress = (xp / nextLevelXp) * 100;

  return (
    <Card className="p-5">
      <WidgetHeader title="Nivå & Prestasjoner" icon={Award} action={onViewAll} />

      {/* Level Progress */}
      <div className="mb-4 p-4 bg-gradient-to-br from-ak-primary to-ak-primary-light rounded-xl text-white">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Star size={18} className="text-ak-gold" />
            <span className="text-[14px] font-semibold">Nivå {level}</span>
          </div>
          <span className="text-[12px] text-white/70">{xp} / {nextLevelXp} XP</span>
        </div>
        <div className="h-2 bg-white/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-ak-gold rounded-full transition-all duration-500"
            style={{ width: `${xpProgress}%` }}
          />
        </div>
      </div>

      {/* Recent Achievements */}
      <p className="text-[12px] text-ak-steel mb-2">Siste oppnåelser</p>
      <div className="flex flex-wrap gap-2">
        {achievements.slice(0, 4).map(achievement => (
          <div
            key={achievement.id}
            className="flex items-center gap-2 px-3 py-2 bg-ak-snow rounded-lg"
            title={achievement.description}
          >
            {achievement.icon ? (
              <achievement.icon size={20} className="text-ak-gold" />
            ) : (
              <span className="text-[18px]">{achievement.iconEmoji}</span>
            )}
            <span className="text-[12px] font-medium text-ak-charcoal">{achievement.title}</span>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== WEATHER WIDGET (Golf-focused) =====
const WeatherWidget = ({ weather }) => {
  const defaultWeather = weather || {
    temp: 8,
    condition: 'partly_cloudy',
    wind: 12,
    humidity: 65,
    golfScore: 'Good',
    forecast: [
      { day: 'I dag', temp: 8, condition: 'partly_cloudy' },
      { day: 'I morgen', temp: 10, condition: 'sunny' },
      { day: 'Ons', temp: 7, condition: 'cloudy' },
    ],
  };

  const getConditionIcon = (condition) => {
    switch (condition) {
      case 'sunny': return '☀️';
      case 'partly_cloudy': return '⛅';
      case 'cloudy': return '☁️';
      case 'rainy': return '🌧️';
      default: return '⛅';
    }
  };

  const getGolfScoreColor = (score) => {
    switch (score) {
      case 'Perfect': return 'text-ak-success';
      case 'Good': return 'text-ak-primary';
      case 'Fair': return 'text-ak-gold';
      default: return 'text-ak-steel';
    }
  };

  return (
    <Card className="p-5">
      <WidgetHeader title="Golfvær" icon={({ size, className }) => <span className={className} style={{ fontSize: size }}>⛳</span>} />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <span className="text-[40px]">{getConditionIcon(defaultWeather.condition)}</span>
          <div>
            <p className="text-[32px] font-bold text-ak-charcoal">{defaultWeather.temp}°</p>
            <p className="text-[12px] text-ak-steel">Oslo</p>
          </div>
        </div>
        <div className="text-right">
          <p className={`text-[14px] font-semibold ${getGolfScoreColor(defaultWeather.golfScore)}`}>
            {defaultWeather.golfScore} for golf
          </p>
          <p className="text-[11px] text-ak-steel mt-1">Vind: {defaultWeather.wind} km/t</p>
        </div>
      </div>

      <div className="flex gap-2 pt-3 border-t border-ak-mist">
        {defaultWeather.forecast.map((day, idx) => (
          <div key={idx} className="flex-1 text-center p-2 bg-ak-snow rounded-lg">
            <p className="text-[11px] text-ak-steel mb-1">{day.day}</p>
            <span className="text-[20px]">{getConditionIcon(day.condition)}</span>
            <p className="text-[12px] font-medium text-ak-charcoal">{day.temp}°</p>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== QUICK ACTIONS WIDGET =====
const QuickActionsWidget = ({ onNavigate }) => {
  const actions = [
    { id: 'session', label: 'Start økt', icon: Play, color: 'bg-ak-primary', path: '/sessions' },
    { id: 'log', label: 'Logg runde', icon: Target, color: 'bg-ak-success', path: '/runder/ny' },
    { id: 'goal', label: 'Sett mål', icon: CheckCircle2, color: 'bg-ak-gold', path: '/maalsetninger' },
    { id: 'message', label: 'Melding', icon: MessageCircle, color: 'bg-ak-primary-light', path: '/notater' },
  ];

  return (
    <Card className="p-5">
      <WidgetHeader title="Hurtighandlinger" icon={Play} />
      <div className="grid grid-cols-4 gap-3">
        {actions.map((action) => (
          <button
            key={action.id}
            onClick={() => onNavigate(action.path)}
            className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-ak-snow transition-colors"
          >
            <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center`}>
              <action.icon size={22} className="text-white" />
            </div>
            <span className="text-[11px] font-medium text-ak-charcoal">{action.label}</span>
          </button>
        ))}
      </div>
    </Card>
  );
};

// ===== PERFORMANCE TREND WIDGET =====
const PerformanceTrendWidget = ({ data, onViewAll }) => {
  const defaultData = data || {
    handicap: { current: 8.4, change: -0.3, trend: 'down' },
    roundsThisMonth: 6,
    avgScore: 82,
    bestScore: 78,
    recentScores: [85, 82, 84, 79, 82, 78],
  };

  const maxScore = Math.max(...defaultData.recentScores);
  const minScore = Math.min(...defaultData.recentScores);
  const range = maxScore - minScore || 1;

  return (
    <Card className="p-5">
      <WidgetHeader title="Prestasjonstrender" icon={TrendingUp} action={onViewAll} />

      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center p-3 bg-ak-snow rounded-xl">
          <p className="text-[20px] font-bold text-ak-primary">{defaultData.handicap.current}</p>
          <p className="text-[10px] text-ak-steel">HCP</p>
          <p className={`text-[10px] font-medium ${defaultData.handicap.change < 0 ? 'text-ak-success' : 'text-ak-error'}`}>
            {defaultData.handicap.change > 0 ? '+' : ''}{defaultData.handicap.change}
          </p>
        </div>
        <div className="text-center p-3 bg-ak-snow rounded-xl">
          <p className="text-[20px] font-bold text-ak-charcoal">{defaultData.avgScore}</p>
          <p className="text-[10px] text-ak-steel">Snitt score</p>
        </div>
        <div className="text-center p-3 bg-gradient-to-br from-ak-gold/10 to-ak-gold/5 rounded-xl">
          <p className="text-[20px] font-bold text-ak-gold">{defaultData.bestScore}</p>
          <p className="text-[10px] text-ak-steel">Beste score</p>
        </div>
      </div>

      {/* Mini chart */}
      <div className="h-16 flex items-end gap-1">
        {defaultData.recentScores.map((score, idx) => {
          const height = ((maxScore - score) / range) * 100;
          const normalizedHeight = Math.max(20, Math.min(100, 100 - height));
          return (
            <div key={idx} className="flex-1 flex flex-col items-center">
              <div
                className="w-full bg-ak-primary rounded-t transition-all"
                style={{ height: `${normalizedHeight}%` }}
              />
              <span className="text-[9px] text-ak-steel mt-1">{score}</span>
            </div>
          );
        })}
      </div>
      <p className="text-[10px] text-ak-steel text-center mt-2">Siste 6 runder</p>
    </Card>
  );
};

// ===== GOAL PROGRESS WIDGET =====
const GoalProgressWidget = ({ goals, onViewAll }) => {
  const defaultGoals = goals || [
    { id: 1, title: 'Reduser handicap til 6', current: 8.4, target: 6, unit: 'HCP', progress: 70 },
    { id: 2, title: '30 putter per runde', current: 32, target: 30, unit: 'putter', progress: 85 },
    { id: 3, title: '100 treningsøkter', current: 68, target: 100, unit: 'økter', progress: 68 },
  ];

  return (
    <Card className="p-5">
      <WidgetHeader title="Målframgang" icon={Target} action={onViewAll} />

      <div className="space-y-4">
        {defaultGoals.map((goal) => (
          <div key={goal.id}>
            <div className="flex justify-between items-center mb-1">
              <p className="text-[13px] font-medium text-ak-charcoal">{goal.title}</p>
              <p className="text-[11px] text-ak-steel">{goal.current}/{goal.target} {goal.unit}</p>
            </div>
            <div className="h-2 bg-ak-mist rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${goal.progress >= 100 ? 'bg-ak-success' : goal.progress >= 75 ? 'bg-ak-primary' : goal.progress >= 50 ? 'bg-ak-gold' : 'bg-ak-primary-light'}`}
                style={{ width: `${Math.min(goal.progress, 100)}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== RECENT TESTS WIDGET =====
const RecentTestsWidget = ({ tests, onViewAll }) => {
  const defaultTests = tests || [
    { id: 1, name: 'Putting Test', date: '18. jan', score: 85, maxScore: 100, improvement: 5 },
    { id: 2, name: 'Driving Accuracy', date: '15. jan', score: 72, maxScore: 100, improvement: -2 },
    { id: 3, name: 'Short Game', date: '10. jan', score: 88, maxScore: 100, improvement: 8 },
  ];

  return (
    <Card className="p-5">
      <WidgetHeader title="Siste tester" icon={Target} action={onViewAll} />

      <div className="space-y-3">
        {defaultTests.map((test) => (
          <div key={test.id} className="flex items-center gap-3 p-3 bg-ak-snow rounded-lg">
            <div className="w-10 h-10 rounded-lg bg-ak-primary/10 flex items-center justify-center">
              <Target size={18} className="text-ak-primary" />
            </div>
            <div className="flex-1">
              <p className="text-[13px] font-medium text-ak-charcoal">{test.name}</p>
              <p className="text-[11px] text-ak-steel">{test.date}</p>
            </div>
            <div className="text-right">
              <p className="text-[16px] font-bold text-ak-primary">{test.score}%</p>
              <p className={`text-[10px] font-medium ${test.improvement > 0 ? 'text-ak-success' : test.improvement < 0 ? 'text-ak-error' : 'text-ak-steel'}`}>
                {test.improvement > 0 ? '+' : ''}{test.improvement}%
              </p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ===== NOTIFICATIONS WIDGET =====
const NotificationsWidget = ({ notifications, onViewAll }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'goal': return <Target size={16} className="text-ak-primary" />;
      case 'note': return <MessageCircle size={16} className="text-ak-primary" />;
      case 'session': return <Calendar size={16} className="text-ak-primary" />;
      case 'achievement': return <Trophy size={16} className="text-ak-gold" />;
      default: return <Info size={16} className="text-ak-primary" />;
    }
  };

  const getNotificationStyle = (type) => {
    switch (type) {
      case 'achievement': return 'bg-ak-gold/10 border-ak-gold/30';
      default: return 'bg-ak-primary/5 border-ak-primary/20';
    }
  };

  return (
    <Card className="p-5">
      <WidgetHeader title="Varsler" icon={Bell} action={onViewAll} />

      <div className="space-y-2">
        {notifications.length === 0 ? (
          <div className="text-center py-6">
            <Bell size={24} className="text-ak-mist mx-auto mb-2" />
            <p className="text-[13px] text-ak-steel">Ingen nye varsler</p>
          </div>
        ) : (
          notifications.slice(0, 5).map(notification => (
            <div
              key={notification.id}
              className={`flex items-start gap-3 p-3 rounded-lg border ${getNotificationStyle(notification.type)}`}
            >
              <div className="flex-shrink-0 mt-0.5">
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-medium text-ak-charcoal">
                  {notification.title}
                </p>
                <p className="text-[12px] text-ak-steel mt-0.5">
                  {notification.message}
                </p>
                <span className="text-[10px] text-ak-steel mt-1 block">
                  {notification.time}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};

// ===== SESSION CARD WITH LOCATION =====
const SessionCardCompact = ({ session, onClick }) => {
  const statusColors = {
    completed: 'bg-ak-success',
    current: 'bg-ak-primary',
    upcoming: 'bg-ak-steel',
  };

  return (
    <div
      className="flex items-center gap-3 p-3 bg-ak-snow rounded-xl cursor-pointer hover:bg-ak-mist transition-all"
      onClick={onClick}
    >
      <div className={`w-12 h-12 rounded-lg ${statusColors[session.status] || 'bg-ak-primary'} flex items-center justify-center`}>
        <Play size={20} className="text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[14px] font-medium text-ak-charcoal truncate">{session.title}</p>
        <div className="flex items-center gap-3 text-[12px] text-ak-steel">
          <span className="flex items-center gap-1">
            <Clock size={12} /> {session.time}
          </span>
          <span className="flex items-center gap-1">
            <MapPin size={12} /> {session.location}
          </span>
        </div>
      </div>
      <div className="text-right">
        <span className="text-[11px] px-2 py-1 bg-white rounded-lg text-ak-primary font-medium">
          {session.duration} min
        </span>
      </div>
    </div>
  );
};

// ===== MAIN DASHBOARD COMPONENT =====
const AKGolfDashboard = () => {
  const navigate = useNavigate();
  const { data: dashboardData, loading, error, refetch } = useDashboard();

  const [tasks, setTasks] = useState([]);

  // Update tasks when data loads
  React.useEffect(() => {
    if (dashboardData?.tasks) {
      setTasks(dashboardData.tasks);
    }
  }, [dashboardData]);

  const toggleTask = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'God morgen';
    if (hour < 18) return 'God dag';
    return 'God kveld';
  };

  // Navigation handlers for "Se alle" buttons
  const handleViewStats = () => navigate('/treningsstatistikk');
  const handleViewTasks = () => navigate('/maalsetninger');
  const handleViewMessages = () => navigate('/notater');
  const handleViewAchievements = () => navigate('/achievements');
  const handleViewNotifications = () => navigate('/notater');

  // Show loading skeletons
  if (loading) {
    return (
      <div style={{ fontFamily: '"Inter", -apple-system, system-ui, sans-serif' }}>
        <div className="mb-6">
          <SkeletonPulse className="h-8 w-64 mb-2" />
          <SkeletonPulse className="h-5 w-48" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-8 space-y-5 order-2 lg:order-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <CountdownSkeleton />
              <CountdownSkeleton />
            </div>
            <CardSkeleton>
              <SkeletonPulse className="h-5 w-24 mb-4" />
              <SkeletonPulse className="h-[400px] w-full rounded-lg" />
            </CardSkeleton>
          </div>

          <div className="lg:col-span-4 space-y-5 order-1 lg:order-2">
            <StatsSkeleton />
            <TasksSkeleton />
          </div>
        </div>
      </div>
    );
  }

  // Show error state
  if (error && !dashboardData) {
    return (
      <div style={{ fontFamily: '"Inter", -apple-system, system-ui, sans-serif' }}>
        <div className="mb-6">
          <h1 className="text-[28px] font-bold text-ak-charcoal">Dashboard</h1>
        </div>
        <ErrorState message={error} onRetry={refetch} />
      </div>
    );
  }

  // Extract data with fallbacks
  const player = dashboardData?.player || { name: 'Spiller', category: 'B' };
  const trainingStats = dashboardData?.stats || { sessionsCompleted: 0, sessionsTotal: 12, hoursThisWeek: 0, hoursGoal: 20, streak: 0 };
  const nextTournament = dashboardData?.nextTournament || { title: 'Ingen turnering', date: '2026-01-01', location: '' };
  const nextTest = dashboardData?.nextTest || { title: 'Ingen test', date: '2026-01-01', location: '' };
  const messages = dashboardData?.messages || [];
  const achievements = dashboardData?.achievements || [];
  const notifications = dashboardData?.notifications || [];
  const calendarEvents = dashboardData?.calendarEvents || [];
  const upcomingSessions = dashboardData?.upcomingSessions || [];

  return (
    <div style={{ fontFamily: '"Inter", -apple-system, system-ui, sans-serif' }}>
      {/* Error banner if API failed but we have fallback data */}
      {error && (
        <div className="mb-4 p-3 bg-ak-warning/10 border border-ak-warning/20 rounded-lg flex items-center gap-3">
          <AlertCircle size={18} className="text-ak-warning" />
          <span className="text-[13px] text-ak-charcoal">Bruker demo-data. {error}</span>
          <button onClick={refetch} className="ml-auto text-[12px] text-ak-primary font-medium hover:underline">
            Prøv igjen
          </button>
        </div>
      )}

      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-[28px] font-bold text-ak-charcoal">
          {getGreeting()}, {player.name.split(' ')[0]}
        </h1>
        <p className="text-[15px] text-ak-steel mt-1">
          Kategori {player.category} · Her er din oversikt for i dag
        </p>
      </div>

      {/* Dashboard Grid - Responsive layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column - Main content */}
        <div className="lg:col-span-8 space-y-5 order-2 lg:order-1">
          {/* Countdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="p-4">
              <CountdownWidget
                title={nextTournament.title}
                date={nextTournament.date}
                type="tournament"
                location={nextTournament.location}
              />
            </Card>
            <Card className="p-4">
              <CountdownWidget
                title={nextTest.title}
                date={nextTest.date}
                type="test"
                location={nextTest.location}
              />
            </Card>
          </div>

          {/* Calendar Day View */}
          <DagensPlan events={calendarEvents} />

          {/* Upcoming Sessions */}
          <Card className="p-5">
            <WidgetHeader
              title="Dagens økter"
              icon={Play}
              action={() => navigate('/kalender')}
            />
            {upcomingSessions.length === 0 ? (
              <div className="text-center py-8">
                <Calendar size={32} className="text-ak-mist mx-auto mb-2" />
                <p className="text-[14px] text-ak-steel">Ingen økter i dag</p>
                <button
                  onClick={() => navigate('/kalender')}
                  className="mt-3 text-[13px] text-ak-primary font-medium hover:underline"
                >
                  Gå til kalender
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {upcomingSessions.map(session => (
                  <SessionCardCompact
                    key={session.id}
                    session={session}
                    onClick={() => navigate(`/session/${session.id}`)}
                  />
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Right Column - Sidebar widgets */}
        <div className="lg:col-span-4 space-y-5 order-1 lg:order-2">
          {/* Quick Actions - NEW */}
          <QuickActionsWidget onNavigate={navigate} />

          {/* Weather Widget - NEW */}
          <WeatherWidget weather={dashboardData?.weather} />

          {/* Training Stats */}
          <TrainingStatsWidget stats={trainingStats} onViewAll={handleViewStats} />

          {/* Performance Trend - NEW */}
          <PerformanceTrendWidget data={dashboardData?.performance} onViewAll={handleViewStats} />

          {/* Goal Progress - NEW */}
          <GoalProgressWidget goals={dashboardData?.goalProgress} onViewAll={handleViewTasks} />

          {/* Session Evaluation */}
          <SessionEvaluationWidget />

          {/* Tasks */}
          <TasksWidget tasks={tasks} onToggle={toggleTask} onViewAll={handleViewTasks} />

          {/* Recent Tests - NEW */}
          <RecentTestsWidget tests={dashboardData?.recentTests} onViewAll={() => navigate('/tests')} />

          {/* Notifications */}
          <NotificationsWidget notifications={notifications} onViewAll={handleViewNotifications} />

          {/* Messages */}
          <MessagesWidget messages={messages} onViewAll={handleViewMessages} />

          {/* Gamification */}
          <GamificationWidget
            achievements={achievements}
            xp={2450}
            level={12}
            nextLevelXp={3000}
            onViewAll={handleViewAchievements}
          />
        </div>
      </div>
    </div>
  );
};

export default AKGolfDashboard;
