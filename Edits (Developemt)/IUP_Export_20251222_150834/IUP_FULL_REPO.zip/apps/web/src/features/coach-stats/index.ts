export { default as CoachStatsOverview } from './CoachStatsOverview';
export { default as CoachStatsProgress } from './CoachStatsProgress';
export { default as CoachStatsRegression } from './CoachStatsRegression';
export { default as CoachDataGolf } from './CoachDataGolf';
