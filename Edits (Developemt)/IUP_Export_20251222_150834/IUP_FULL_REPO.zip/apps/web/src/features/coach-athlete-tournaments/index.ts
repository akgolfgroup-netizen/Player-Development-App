export { default as CoachAthleteTournaments } from './CoachAthleteTournaments';
