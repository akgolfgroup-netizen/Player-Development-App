# AK Golf Academy - App Funksjonalitet

> **KILDE:** `/packages/design-system/figma/ak_golf_complete_figma_kit.svg`
> **Versjon:** v2.1
> **Sist oppdatert:** Desember 2025

---

## Navigasjonsstruktur

```
┌─────────────────────────────────────────────────────────┐
│                      APP STRUKTUR                        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌─────┐  ┌─────────┐  ┌─────┐  ┌───────┐  ┌────────┐  │
│  │Hjem │  │Kalender │  │ Mål │  │ Stats │  │ Profil │  │
│  └─────┘  └─────────┘  └─────┘  └───────┘  └────────┘  │
│                                                          │
│  Bottom Navigation Bar                                   │
└─────────────────────────────────────────────────────────┘
```

---

## 1. Hjem (Dashboard)

### Formål
Gi spilleren en rask oversikt over dagens aktiviteter, fremgang og viktige oppdateringer.

### Innhold

| Seksjon | Beskrivelse | Prioritet |
|---------|-------------|-----------|
| **Velkomst-header** | "God morgen, [Navn]" + dato | Høy |
| **Aktiv periode** | Viser G/F/K/T-periode med fokusområder | Høy |
| **Dagens økter** | Timeline med planlagte treningsøkter | Høy |
| **Ukentlig fremgang** | Komplett/planlagt økter, streak | Medium |
| **Siste badges** | Nylig opptjente merker (horisontal scroll) | Medium |
| **Aktive mål** | 1-2 prioriterte mål med progress | Medium |
| **Meldinger** | Uleste meldinger fra trener/team | Lav |

### Interaksjoner
- [ ] Trykk på økt → Åpne øktdetaljer
- [ ] Trykk på badge → Vis badge-info modal
- [ ] Trykk på mål → Gå til Mål-fanen
- [ ] Trykk på melding → Åpne chat
- [ ] Pull-to-refresh → Oppdater data

---

## 2. Kalender

### Formål
Planlegge, se og administrere treningsøkter og aktiviteter over tid.

### Visninger

| Visning | Beskrivelse |
|---------|-------------|
| **Uke** | Standard visning - 7 dager med økter |
| **Måned** | Oversikt med fargekodede dager |
| **Dag** | Detaljert timeplan for én dag |

### Innhold per dag

```
┌────────────────────────────────────────┐
│  Mandag 16. desember                   │
├────────────────────────────────────────┤
│  09:00  ┌──────────────────────┐       │
│         │ Langspill - Driving  │ 60min │
│         │ L3 · CS80 · S5       │       │
│         └──────────────────────┘       │
│  14:00  ┌──────────────────────┐       │
│         │ Putting - Avstand    │ 45min │
│         │ L2 · S3              │       │
│         └──────────────────────┘       │
└────────────────────────────────────────┘
```

### Funksjoner
- [ ] Se planlagte økter fra treningsplan
- [ ] Se bookede timer med trener
- [ ] Se konkurranser/turneringer
- [ ] Se tester som skal gjennomføres
- [ ] Markere økter som fullført
- [ ] Legge til egne aktiviteter
- [ ] Synkronisere med ekstern kalender (Google/Apple)

### Fargekoding
| Type | Farge |
|------|-------|
| Langspill | `#2C5F7F` Blue Light |
| Kortspill | `#4A7C59` (Success) |
| Putting | `#6B9B7A` |
| Fysisk | `#C9A227` (Gold) |
| Mental | `#8B7355` |
| Spill/Runde | `#10456A` (Blue Primary) |
| Test | `#C45B4E` (Error) |
| Trenertime | `#D4A84B` (Warning) |

---

## 3. Mål

### Formål
Sette, følge opp og oppnå personlige og treningsrelaterte mål.

### Måltyper

| Type | Eksempel | Måleenhet |
|------|----------|-----------|
| **Score** | Senke handicap til 5.0 | Tall |
| **Teknikk** | Øke jernpresisjon til 70% | Prosent |
| **Fysisk** | Øke klubbhastighet til 105 mph | mph/kmh |
| **Konkurranse** | Vinne klubbmesterskap | Ja/Nei |
| **Trening** | Trene 5 økter per uke | Antall |
| **Mental** | Gjennomføre 10 visualiseringsøkter | Antall |

### Tidsrammer
- **Kortsiktig:** 1-4 uker
- **Mellomlang:** 1-3 måneder
- **Langsiktig:** 6-12 måneder
- **Sesong:** Hel sesong

### Visning

```
┌────────────────────────────────────────┐
│  🎯 Senke handicap til 5.0             │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 75%    │
│  7.2 → 5.0  •  Frist: Mars 2026        │
│                                         │
│  Delm��l:                                │
│  ✓ Handicap under 7.0                  │
│  ✓ Handicap under 6.5                  │
│  ○ Handicap under 6.0                  │
│  ○ Handicap under 5.5                  │
└────────────────────────────────────────┘
```

### Funksjoner
- [ ] Opprette nye mål
- [ ] Sette delmål/milepæler
- [ ] Koble mål til tester (automatisk oppdatering)
- [ ] Se historikk/progress over tid
- [ ] Dele mål med trener
- [ ] Få påminnelser
- [ ] Arkivere fullførte mål

---

## 4. Statistikk

### Formål
Gi innsikt i treningsdata, testresultater og utvikling over tid.

### Hovedseksjoner

#### 4.1 Treningsoversikt
| Metrikk | Beskrivelse |
|---------|-------------|
| **Økter denne uken** | Antall fullførte vs planlagte |
| **Total treningstid** | Timer denne uke/måned/år |
| **Fullføringsgrad** | Prosent av planlagte økter |
| **Streak** | Dager på rad med trening |
| **Treningsfordeling** | Pie chart per kategori |

#### 4.2 Treningsfordeling
```
┌────────────────────────────────────────┐
│  Treningsfordeling (denne måneden)     │
│                                         │
│  ████████████░░░░░░  Langspill   35%   │
│  ████████░░░░░░░░░░  Kortspill   25%   │
│  ██████░░░░░░░░░░░░  Putting     20%   │
│  ████░░░░░░░░░░░░░░  Fysisk      12%   │
│  ██░░░░░░░░░░░░░░░░  Spill        8%   │
└────────────────────────────────────────┘
```

#### 4.3 Testresultater
| Test | Siste | Beste | Trend |
|------|-------|-------|-------|
| Jerntreffsikkerhet | 68% | 72% | ↗️ |
| Putting 1.5m | 85% | 88% | → |
| Driving distance | 245m | 252m | ↗️ |

#### 4.4 Lærings fase-distribusjon
- L1 Bevisstgjøring
- L2 Isolert trening
- L3 Variasjon
- L4 Tilfeldighet
- L5 Automatikk

### Tidsperioder
- Denne uken
- Denne måneden
- Siste 3 måneder
- Dette året
- Egendefinert periode

### Funksjoner
- [ ] Se treningsstatistikk
- [ ] Se testresultater over tid (grafer)
- [ ] Sammenligne med tidligere perioder
- [ ] Eksportere data (PDF/CSV)
- [ ] Se breaking points status
- [ ] Se kategori-progresjon

---

## 5. Profil

### Formål
Administrere personlig informasjon, innstillinger og se oppnåelser.

### Seksjoner

#### 5.1 Profilinformasjon
- Navn og bilde
- Kategori (A/B/C/Junior)
- Handicap
- Klubb
- Trener(e)
- Medlem siden

#### 5.2 Merker/Achievements
```
┌────────────────────────────────────────┐
│  Mine merker (12)                      │
│                                         │
│  💎 Platinum (1)  🏆 Gull (3)          │
│  🥈 Sølv (4)      🥉 Bronse (4)        │
│                                         │
│  Siste opptjent:                       │
│  🏆 7-dagers streak - 14. des          │
│  🥈 100 økter fullført - 10. des       │
└────────────────────────────────────────┘
```

#### 5.3 Innstillinger
| Innstilling | Beskrivelse |
|-------------|-------------|
| **Varsler** | Push-varsler for økter, meldinger |
| **Personvern** | Hvem kan se min profil |
| **Utseende** | Lys/mørk modus |
| **Språk** | Norsk/Engelsk |
| **Kalender-sync** | Google/Apple kalender |
| **Eksporter data** | Last ned mine data |

#### 5.4 Trenerteam
- Liste over trenere
- Kontaktinformasjon
- Booking av timer

### Funksjoner
- [ ] Redigere profilbilde
- [ ] Oppdatere personinfo
- [ ] Se alle merker med beskrivelser
- [ ] Administrere varsler
- [ ] Bytte tema
- [ ] Logge ut

---

## 6. Treningsøkt - Detaljvisning

> **Skjerm:** Vises når spiller trykker på en økt fra Dashboard eller Kalender
> **Basert på:** AK_Golf_Kategori_Hierarki

---

### 6.1 Økt-header

Øverst på skjermen vises økt-metadata:

| Felt | Type | Eksempel | Beskrivelse |
|------|------|----------|-------------|
| **Dato** | Date | Mandag 16. desember | Dato for økten |
| **Tidspunkt** | Time | 09:00 - 11:00 | Start- og sluttid |
| **Varighet** | Minutes | 120 min | Total varighet |
| **Sted** | String | Driving Range, Miklagard | Lokasjon |
| **Status** | Enum | Planlagt / Pågår / Fullført | Øktens status |

---

### 6.2 Blokk-struktur

En økt inneholder **flere blokker**. Hver blokk har:

| Felt | Type | Eksempel | Beskrivelse |
|------|------|----------|-------------|
| **Varighet** | Minutes | 30 | Blokkens varighet |
| **Repetisjoner** | Number | 300 | Antall repetisjoner |
| **Øvelse** | String | Pyramiden | Navn på øvelse/protokoll |
| **Fokus** | String | Teknikk | Hva spilleren skal fokusere på |
| **Treningsområde** | String | Innspill 100-150m | Spesifikt område/slag |
| **Læringsfase** | Enum | Ball | Fase i læringsprosessen |
| **CS-nivå** | Percent | 80% | Klubbhastighet |
| **Miljø** | Enum | M3 | Hvor treningen skjer |
| **Belastning** | Enum | PR2 | Pressnivå |

---

### 6.3 Skjermvisning

```
┌─────────────────────────────────────────────────────────────┐
│  ← Tilbake                                    ⋮ Meny        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  TRENINGSØKT                                                │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  📅  Mandag 16. desember 2025                               │
│  🕐  09:00 - 11:00 (120 min)                                │
│  📍  Driving Range, Miklagard                               │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ○ Planlagt    ● Pågår    ○ Fullført               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  BLOKK 1 av 4                                   30 min      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │  📋 Pyramiden                                        │    │
│  │  Fokus: Teknikk                                     │    │
│  │                                                      │    │
│  │  Treningsområde                                     │    │
│  │  Innspill 100-150 meter                             │    │
│  │                                                      │    │
│  │  Volum                                              │    │
│  │  300 repetisjoner                                   │    │
│  │                                                      │    │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │    │
│  │  │ Ball   │ │ CS 80% │ │  M3    │ │  PR2   │       │    │
│  │  │Lærings-│ │ Klubb- │ │ Miljø  │ │Belast- │       │    │
│  │  │fase    │ │hastigh.│ │        │ │ning    │       │    │
│  │  └────────┘ └────────┘ └────────┘ └────────┘       │    │
│  │                                                      │    │
│  │  [ Vis instruksjoner ▼ ]                            │    │
│  │                                                      │    │
│  │  ┌──────────────────────────────────────────────┐   │    │
│  │  │  ☐ Marker som fullført                       │   │    │
│  │  └──────────────────────────────────────────────┘   │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  BLOKK 2 av 4                                   30 min      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │  📋 Scattered                                        │    │
│  │  Fokus: Variasjon                                   │    │
│  │                                                      │    │
│  │  Treningsområde                                     │    │
│  │  Innspill 50-100 meter                              │    │
│  │                                                      │    │
│  │  Volum                                              │    │
│  │  200 repetisjoner                                   │    │
│  │                                                      │    │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │    │
│  │  │Transfer│ │ CS 90% │ │  M4    │ │  PR3   │       │    │
│  │  └────────┘ └────────┘ └────────┘ └────────┘       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  BLOKK 3 av 4                                   30 min      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📋 9-holes putting                                  │    │
│  │  Fokus: Spill                                       │    │
│  │  Putting • 50 reps                                  │    │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │    │
│  │  │ Spill  │ │ CS100% │ │  M5    │ │  PR4   │       │    │
│  │  └────────┘ └────────┘ └────────┘ └────────┘       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  BLOKK 4 av 4                                   30 min      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📋 Fysisk: Mobilitet                                │    │
│  │  Kjernemuskulatur • 3 sett x 12 reps                │    │
│  │  ┌────────┐ ┌────────┐                              │    │
│  │  │ Fysisk │ │  PR2   │                              │    │
│  │  └────────┘ └────────┘                              │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  📝 Notater                                                 │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Legg til notater fra økten...                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │            [ Start økt ]                            │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 6.4 Interaksjoner

| Handling | Resultat |
|----------|----------|
| **Trykk på blokk** | Utvider blokken med full info |
| **"Vis instruksjoner"** | Viser detaljerte øvelsesinstruksjoner |
| **"Marker som fullført"** | Checkbox for å markere blokk ferdig |
| **"Start økt"** | Starter timer, endrer status til "Pågår" |
| **"Fullfør økt"** | Lagrer data, ber om refleksjon |
| **Notater-felt** | Fritekst for spillerens notater |
| **Meny (⋮)** | Rediger, del med trener, eksporter |

---

### 6.5 Kategori-referanse

#### Læringsfaser

| Kode | Navn | Beskrivelse | Farge |
|------|------|-------------|-------|
| **Ball** | Ballfokus | Fokus på ballkontakt og resultat | `#E8F5E9` |
| **Teknikk** | Teknikkfokus | Fokus på bevegelsesmønster | `#C8E6C9` |
| **Transfer** | Overføring | Koble teknikk til spill | `#A5D6A7` |
| **Variasjon** | Variasjonstrening | Ulike situasjoner | `#81C784` |
| **Spill** | Spillfokus | Konkurranselignende | `#66BB6A` |

#### Klubbhastighet (CS-nivå)

| Nivå | Prosent | Beskrivelse | Farge |
|------|---------|-------------|-------|
| **CS20** | 20% | Svært lav - oppvarming | `#EDF0F2` |
| **CS40** | 40% | Lav - teknikk | `#E8F5E9` |
| **CS60** | 60% | Medium - kontroll | `#C8E6C9` |
| **CS80** | 80% | Høy - normal | `#A5D6A7` |
| **CS100** | 100% | Full - konkurranse | `#10456A` |

#### Miljø (Environment)

| Kode | Navn | Beskrivelse | Farge |
|------|------|-------------|-------|
| **M1** | Inne | Simulator/innendørs | `#E5E5EA` |
| **M2** | Matte | Driving range matte | `#EDF0F2` |
| **M3** | Treningsområde | Gress, range | `#C8E6C9` |
| **M4** | Øvingsbane | Kortbane, par-3 | `#A5D6A7` |
| **M5** | Bane | Full golfbane | `#10456A` |

#### Belastning (Pressure Rating)

| Kode | Navn | Beskrivelse | Farge |
|------|------|-------------|-------|
| **PR1** | Ingen press | Fri trening | `#EDF0F2` |
| **PR2** | Lavt press | Personlige mål | `#FFF9E6` |
| **PR3** | Medium press | Mot seg selv | `#FFE082` |
| **PR4** | Høyt press | Mot andre | `#D4A84B` |
| **PR5** | Maks press | Turnering/test | `#C9A227` |

---

---

## 7. Aktiv Økt - Under Trening

> **Skjerm:** Vises når spiller har trykket "Start økt"
> **Modus:** Fokusert treningsvisning med timer

---

### 7.1 Aktiv økt-header

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                      02:34:15                         │  │
│  │                   Total økttid                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  Blokk 2 av 4                          ███████░░░ 50%       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 7.2 Aktiv blokk-visning

```
┌─────────────────────────────────────────────────────────────┐
│  ← Pause                                      Avslutt økt   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│                        15:42                                │
│                    ━━━━━━━━━━━━━━━━                         │
│                   Gjenstående tid                           │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │  BLOKK 2: Scattered                                 │    │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━   │    │
│  │                                                      │    │
│  │  Fokus                                              │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │  🎯 Variasjon                                │   │    │
│  │  │  Bytt mål og klubb for hvert slag           │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                      │    │
│  │  Treningsområde                                     │    │
│  │  Innspill 50-100 meter                              │    │
│  │                                                      │    │
│  │  Volum                                              │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │         87 / 200 repetisjoner               │   │    │
│  │  │         ████████████░░░░░░░░░░ 44%          │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                      │    │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │    │
│  │  │Transfer│ │ CS 90% │ │  M4    │ │  PR3   │       │    │
│  │  └────────┘ └────────┘ └────────┘ └────────┘       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Repetisjonsteller                                          │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │      ┌─────┐              87              ┌─────┐   │    │
│  │      │  -  │                              │  +  │   │    │
│  │      └─────┘                              └─────┘   │    │
│  │                                                      │    │
│  │              [ + 10 ]    [ + 25 ]                   │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Neste blokk → ]                          │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📝 Legg til notat...                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 7.3 Blokk-navigasjon

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  Alle blokker                                               │
│                                                              │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐                    │
│  │  ✓   │  │  2   │  │  3   │  │  4   │                    │
│  │ 30m  │  │ 30m  │  │ 30m  │  │ 30m  │                    │
│  │Pyram.│  │Scatt.│  │Putt. │  │Fysisk│                    │
│  └──────┘  └──────┘  └──────┘  └──────┘                    │
│   Fullført   Aktiv   Kommende  Kommende                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 7.4 Pause-modus

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                        ⏸️ PAUSE                              │
│                                                              │
│                     Økten er pauset                         │
│                                                              │
│                   Total tid: 01:15:42                       │
│                   Pause: 00:02:34                           │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │              [ ▶️ Fortsett økt ]                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │              [ Avslutt økt ]                        │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 7.5 Fullført blokk - Kvalitetsvurdering

Vises når spiller fullfører en blokk eller trykker "Neste blokk":

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  ✓ Blokk 1 fullført                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Pyramiden: Teknikk                                         │
│  Innspill 100-150m • 300 reps • 32:15                      │
│                                                              │
│  Hvordan gikk det?                                          │
│                                                              │
│  Kvalitet                                                   │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😟     😐     🙂     😊     🤩                      │    │
│  │   1      2      3      4      5                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Fokus                                                      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😟     😐     🙂     😊     🤩                      │    │
│  │   1      2      3      4      5                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Intensitet                                                 │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  💤     😴     💪     🔥     ⚡                      │    │
│  │   1      2      3      4      5                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Notat (valgfritt)                                         │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Følte god kontakt på de siste 100 slagene...       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Lagre og fortsett → ]                    │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│                    [ Hopp over ]                            │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 7.6 Data som lagres under aktiv økt

| Felt | Type | Beskrivelse |
|------|------|-------------|
| **startTime** | DateTime | Når økten startet |
| **endTime** | DateTime | Når økten ble avsluttet |
| **totalDuration** | Minutes | Faktisk tid brukt |
| **pauseDuration** | Minutes | Tid i pause |
| **blocksCompleted** | Number | Antall fullførte blokker |

**Per blokk:**
| Felt | Type | Beskrivelse |
|------|------|-------------|
| **actualDuration** | Minutes | Faktisk tid på blokken |
| **actualReps** | Number | Faktiske repetisjoner |
| **qualityRating** | 1-5 | Spillerens vurdering |
| **focusRating** | 1-5 | Fokus under blokken |
| **intensityRating** | 1-5 | Intensitetsnivå |
| **notes** | String | Spillerens notater |
| **completedAt** | DateTime | Tidspunkt fullført |

---

### 7.7 Interaksjoner

| Handling | Resultat |
|----------|----------|
| **+/- knapper** | Øker/minker rep-teller |
| **+10, +25** | Hurtigknapper for reps |
| **Neste blokk** | Viser kvalitetsvurdering, går til neste |
| **Pause** | Stopper timer, viser pause-skjerm |
| **Avslutt økt** | Går til fullføring/refleksjon |
| **Blokk-chips** | Hopp til spesifikk blokk |
| **Notat-felt** | Åpner tastatur for notater |

---

---

## 8. Refleksjon etter fullført økt

> **Skjerm:** Vises når spiller har fullført alle blokker eller trykker "Avslutt økt"
> **Formål:** Samle data for treningsanalyse og utvikling

---

### 8.1 Refleksjonsskjerm

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  ✓ Økt fullført!                                            │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Mandag 16. desember • 02:15:42                             │
│  4 av 4 blokker fullført                                    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  REFLEKSJON                                                 │
│                                                              │
│  Fokus                                                      │
│  Hvor godt klarte du å holde fokus gjennom økten?          │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😟     😐     🙂     😊     🤩                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Svært   Lav   Medium  Høy   Svært                   │    │
│  │  lav                         høy                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Energinivå                                                 │
│  Hvordan var energinivået ditt under økten?                │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😴     🥱     😐     💪     ⚡                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Svært  Sliten Normal  Bra   Topp                    │    │
│  │ sliten                       form                    │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Motivasjon                                                 │
│  Hvor motivert var du under økten?                         │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😞     😕     😐     🙂     🔥                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Svært   Lav   Medium  Høy   Svært                   │    │
│  │  lav                         høy                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Teknisk utførelse                                         │
│  Hvordan opplevde du den tekniske utførelsen?              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😟     😐     🙂     😊     🤩                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Mye    Noe    OK     Bra   Svært                    │    │
│  │ feil   ustødig              bra                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Mental tilstand                                           │
│  Hvordan var din mentale tilstand?                         │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😰     😟     😐     😌     🧘                      │    │
│  │   1      2      3      4      5                      │    │
│  │Stresset Urolig Nøytral Rolig  Fokusert             │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Fysisk tilstand                                           │
│  Hvordan føltes kroppen under økten?                       │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  🤕     😣     😐     💪     🏃                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Vondt  Stiv  Normal  Bra   Optimal                  │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Søvn siste natt                                           │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  < 5t    5-6t    6-7t    7-8t    > 8t              │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Søvnkvalitet                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  😫     😴     😐     😊     🌟                      │    │
│  │   1      2      3      4      5                      │    │
│  │ Dårlig        Medium        Utmerket                │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Hva gikk bra?                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Skriv her...                                       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Hva kan forbedres?                                        │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Skriv her...                                       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Mål for neste økt                                         │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Skriv her...                                       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Lagre refleksjon ]                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│                    [ Hopp over ]                            │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 8.2 Refleksjonsdata

| Kategori | Felt | Type | Skala | Beskrivelse |
|----------|------|------|-------|-------------|
| **Mental** | fokus | 1-5 | Lav → Høy | Evne til å holde konsentrasjon |
| **Mental** | motivasjon | 1-5 | Lav → Høy | Indre driv under økten |
| **Mental** | mentalTilstand | 1-5 | Stresset → Fokusert | Generell mental tilstand |
| **Fysisk** | energiniva | 1-5 | Sliten → Topp | Opplevd energi |
| **Fysisk** | fysiskTilstand | 1-5 | Vondt → Optimal | Kroppslig tilstand |
| **Teknisk** | tekniskUtforelse | 1-5 | Mye feil → Svært bra | Kvalitet på teknikk |
| **Restitusjon** | sovnTimer | Enum | <5t, 5-6t, 6-7t, 7-8t, >8t | Timer søvn |
| **Restitusjon** | sovnKvalitet | 1-5 | Dårlig → Utmerket | Kvalitet på søvn |
| **Refleksjon** | hvaBra | String | Fritekst | Positive observasjoner |
| **Refleksjon** | hvaForbedres | String | Fritekst | Forbedringsområder |
| **Refleksjon** | malNesteOkt | String | Fritekst | Mål framover |

---

### 8.3 Toppidrettsperspektiv

Refleksjonsspørsmålene er basert på anerkjente prinsipper fra toppidrettsfaget:

| Prinsipp | Implementering |
|----------|----------------|
| **Periodisering** | Energinivå + søvn hjelper med å justere treningsbelastning |
| **Restitusjon** | Søvndata og fysisk tilstand gir innsikt i restitusjonstatus |
| **Mental trening** | Fokus, motivasjon og mental tilstand tracker psykisk form |
| **Selvregulering** | Fritekst-refleksjon fremmer bevisstgjøring og læring |
| **Målsetting** | "Mål for neste økt" kobler refleksjon til handling |
| **Helhetlig utvikling** | Kombinerer fysisk, teknisk og mental dimensjon |

---

## 9. Treningsområder

> **REFERANSE:** Alltid koblet til AK_Golf_Kategori_Hierarki
> **Kilde:** `/reference/training/` dokumenter

---

### 9.1 Hovedkategorier

| Kode | Kategori | Beskrivelse |
|------|----------|-------------|
| **LS** | Langspill | Driver, fairway, hybrider |
| **KS** | Kortspill | Innspill, pitching, chipping |
| **PT** | Putting | Alle putteavstander |
| **FY** | Fysisk | Styrke, mobilitet, kondisjon |
| **ME** | Mental | Visualisering, fokus, rutiner |
| **SP** | Spill | Runder, simulert konkurranse |

---

### 9.2 Langspill (LS)

| Kode | Treningsområde | Avstand | Beskrivelse |
|------|----------------|---------|-------------|
| **LS-DRV** | Driver | 200m+ | Utslagsdriver |
| **LS-FW3** | Fairway tre | 180-220m | 3-tre, 5-tre |
| **LS-HYB** | Hybrid | 160-200m | Rescue/hybrid |
| **LS-LI** | Lange jern | 150-180m | 4-5-6 jern |
| **LS-MI** | Mellomjern | 120-150m | 7-8 jern |
| **LS-SI** | Korte jern | 100-130m | 9-PW |

---

### 9.3 Kortspill (KS)

| Kode | Treningsområde | Avstand | Beskrivelse |
|------|----------------|---------|-------------|
| **KS-100** | Innspill 100m | 90-110m | Full sving, wedge |
| **KS-75** | Innspill 75m | 65-85m | 3/4 sving |
| **KS-50** | Innspill 50m | 40-60m | Halv sving |
| **KS-30** | Pitch 30m | 20-40m | Pitch shot |
| **KS-CH** | Chipping | 5-20m | Chip shot, bump & run |
| **KS-BU** | Bunkerslag | Variabel | Greenside bunker |
| **KS-FBU** | Fairway bunker | Variabel | Lang bunker |
| **KS-LOB** | Lob shot | 10-30m | Høye slag over hinder |

---

### 9.4 Putting (PT)

| Kode | Treningsområde | Avstand | Beskrivelse |
|------|----------------|---------|-------------|
| **PT-S** | Korte putter | 0-1.5m | Make-putts |
| **PT-M** | Mellomputter | 1.5-5m | Scoring range |
| **PT-L** | Lange putter | 5-10m | Lag putts |
| **PT-XL** | Svært lange | 10m+ | Distansekontroll |
| **PT-BR** | Break-lesing | Alle | Greenslesing |
| **PT-SP** | Speed control | Alle | Fartkontroll |
| **PT-RU** | Rutine | Alle | Pre-putt rutine |

---

### 9.5 Fysisk (FY)

| Kode | Treningsområde | Fokus | Beskrivelse |
|------|----------------|-------|-------------|
| **FY-MOB** | Mobilitet | Bevegelighet | Dynamisk tøying |
| **FY-STY** | Styrke | Kraft | Vekttrening |
| **FY-KOR** | Kjerne | Core | Kjernemuskulatur |
| **FY-EKS** | Eksplosivitet | Power | Hurtig kraft |
| **FY-KON** | Kondisjon | Utholdenhet | Aerob kapasitet |
| **FY-BAL** | Balanse | Stabilitet | Propriosepsjon |
| **FY-OPP** | Oppvarming | Forberedelse | Pre-trening |
| **FY-NED** | Nedkjøling | Restitusjon | Post-trening |

---

### 9.6 Mental (ME)

| Kode | Treningsområde | Fokus | Beskrivelse |
|------|----------------|-------|-------------|
| **ME-VIS** | Visualisering | Mentale bilder | Se slaget før utførelse |
| **ME-RUT** | Rutiner | Pre-shot | Forberedelsesrutiner |
| **ME-FOK** | Fokus | Konsentrasjon | Oppmerksomhetstrening |
| **ME-PUS** | Pust | Regulering | Pusteøvelser |
| **ME-SEL** | Selvsnakk | Indre dialog | Positiv selvprat |
| **ME-MÅL** | Målsetting | Mål | Prosess- og resultatmål |
| **ME-ARO** | Arousal | Aktivering | Regulere spenningsnivå |

---

### 9.7 Spill (SP)

| Kode | Treningsområde | Format | Beskrivelse |
|------|----------------|--------|-------------|
| **SP-9** | 9 hull | Runde | Halv runde |
| **SP-18** | 18 hull | Runde | Full runde |
| **SP-SIM** | Simulert | Konkurranse | Turneringssimulering |
| **SP-SCR** | Scramble | Lag | Lagspill |
| **SP-MAT** | Matchplay | Konkurranse | Hull for hull |
| **SP-STR** | Strokeplay | Konkurranse | Slagspill |

---

## 10. Øvelser og Driller

> **Skjerm:** Øvelsesbibliotek - tilgjengelig fra blokk-visning
> **Formål:** Strukturerte treningsprotokoller

---

### 10.1 Øvelseskategorier

| Kategori | Beskrivelse | Eksempler |
|----------|-------------|-----------|
| **Teknikk** | Grunnleggende ferdigheter | Grip, stance, sving |
| **Presisjon** | Treffsikkerhet | Target practice |
| **Variasjon** | Ulike situasjoner | Scattered, random |
| **Press** | Konkurransesimulering | Games, challenges |
| **Spill** | Bane-lignende | Course simulation |

---

### 10.2 Standard øvelser

#### Pyramiden
```
┌─────────────────────────────────────────────────────────────┐
│  📋 PYRAMIDEN                                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Kategori: Teknikk / Presisjon                              │
│  Varighet: 20-30 min                                        │
│  Repetisjoner: 55 slag                                      │
│                                                              │
│  Beskrivelse:                                               │
│  Bygg opp og ned i antall slag til samme mål.               │
│  Fokus på konsistens og repetisjon.                         │
│                                                              │
│  Struktur:                                                  │
│  • Nivå 1: 1 slag                                           │
│  • Nivå 2: 2 slag                                           │
│  • ...                                                       │
│  • Nivå 10: 10 slag (topp)                                  │
│  • Nivå 9: 9 slag                                           │
│  • ...ned til 1                                              │
│                                                              │
│  Varianter:                                                 │
│  • Mini-pyramide (1-5-1): 25 slag                           │
│  • Stor pyramide (1-15-1): 120 slag                         │
│                                                              │
│  Bruksområde: Alle treningsområder                          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### Scattered
```
┌─────────────────────────────────────────────────────────────┐
│  📋 SCATTERED                                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Kategori: Variasjon / Transfer                             │
│  Varighet: 15-30 min                                        │
│  Repetisjoner: Variabel                                     │
│                                                              │
│  Beskrivelse:                                               │
│  Bytt mål og/eller klubb for HVERT slag.                    │
│  Simulerer banespill der ingen slag er like.                │
│                                                              │
│  Regler:                                                    │
│  • Aldri samme mål to ganger på rad                         │
│  • Aldri samme klubb to ganger på rad                       │
│  • Full pre-shot rutine for hvert slag                      │
│                                                              │
│  Varianter:                                                 │
│  • Scattered Light: Bare bytt mål                           │
│  • Scattered Full: Bytt mål + klubb                         │
│  • Scattered Plus: + bytt slagtype                          │
│                                                              │
│  Bruksområde: Kortspill, Innspill                           │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### 9-holes Putting
```
┌─────────────────────────────────────────────────────────────┐
│  📋 9-HOLES PUTTING                                         │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Kategori: Spill / Press                                    │
│  Varighet: 15-25 min                                        │
│  Repetisjoner: 9-18 putter                                  │
│                                                              │
│  Beskrivelse:                                               │
│  Simuler 9 hull på puttinggreenen.                          │
│  Spill mot par med konsekvenser.                            │
│                                                              │
│  Oppsett:                                                   │
│  • 9 ulike posisjoner (hull)                                │
│  • Varierende avstander (1-8m)                              │
│  • Miks av rett, venstre-break, høyre-break                 │
│                                                              │
│  Scoring:                                                   │
│  • Hole-in-one: Birdie (-1)                                 │
│  • 2 putter: Par (0)                                        │
│  • 3 putter: Bogey (+1)                                     │
│  • 4+ putter: Double+ (+2)                                  │
│                                                              │
│  Mål: Under par på 9 hull                                   │
│                                                              │
│  Bruksområde: Putting                                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### Gate Drill
```
┌─────────────────────────────────────────────────────────────┐
│  📋 GATE DRILL                                              │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Kategori: Presisjon / Teknikk                              │
│  Varighet: 10-20 min                                        │
│  Repetisjoner: 20-50 slag                                   │
│                                                              │
│  Beskrivelse:                                               │
│  Sett opp "porter" med tees/sticks som ballen               │
│  må gå gjennom.                                             │
│                                                              │
│  Oppsett:                                                   │
│  • Plasser 2 tees som port foran ballen                     │
│  • Porten skal være ballbredde + 1-2 cm                     │
│  • Varier avstand til port (30cm - 2m)                      │
│                                                              │
│  Varianter:                                                 │
│  • Putting gate: Ved hullet                                 │
│  • Chipping gate: Ved landingssone                          │
│  • Full swing gate: Ved target                              │
│                                                              │
│  Bruksområde: Putting, Chipping, Innspill                   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### Clock Drill
```
┌─────────────────────────────────────────────────────────────┐
│  📋 CLOCK DRILL                                             │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Kategori: Presisjon / Press                                │
│  Varighet: 15-30 min                                        │
│  Repetisjoner: 12+ putter                                   │
│                                                              │
│  Beskrivelse:                                               │
│  Plasser baller rundt hullet som en klokke.                 │
│  Må holde alle 12 for å fullføre.                           │
│                                                              │
│  Oppsett:                                                   │
│  • 12 baller i sirkel rundt hullet                          │
│  • Samme avstand for alle (f.eks. 1m)                       │
│  • Start på kl. 12, gå med klokken                          │
│                                                              │
│  Regler:                                                    │
│  • Miss = start på nytt fra kl. 12                          │
│  • Eller: Miss = gå tilbake til forrige                     │
│                                                              │
│  Varianter:                                                 │
│  • 0.5m, 1m, 1.5m, 2m avstander                             │
│  • 6-balls (halvklokke) for kortere økt                     │
│                                                              │
│  Bruksområde: Putting (korte putter)                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 10.3 Øvelsesdata

| Felt | Type | Beskrivelse |
|------|------|-------------|
| **id** | UUID | Unik identifikator |
| **name** | String | Øvelsesnavn |
| **category** | Enum | Teknikk/Presisjon/Variasjon/Press/Spill |
| **trainingAreas** | Array | Hvilke områder øvelsen dekker |
| **duration** | Range | Min-max tid |
| **reps** | Range | Min-max repetisjoner |
| **description** | String | Beskrivelse |
| **instructions** | String | Steg-for-steg |
| **variants** | Array | Varianter av øvelsen |
| **difficulty** | 1-5 | Vanskelighetsgrad |
| **equipment** | Array | Nødvendig utstyr |
| **videoUrl** | String | Link til instruksjonsvideo |

---

## 11. Tester i blokk

> **Funksjon:** Legge til standardtest som blokk i økt
> **Kobling:** Refererer til testprotokoll-databasen

---

### 11.1 Legge til test

```
┌─────────────────────────────────────────────────────────────┐
│  ← Tilbake                           Legg til blokk         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Velg type                                                  │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📋 Øvelse/Drill                                    │    │
│  │  Velg fra øvelsesbibliotek                          │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📊 TEST                                    ★       │    │
│  │  Legg til standardtest fra testprotokollen          │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  💪 Fysisk øvelse                                   │    │
│  │  Styrke, mobilitet, kondisjon                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  🧘 Mental øvelse                                   │    │
│  │  Visualisering, fokus, rutiner                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ✏️ Egendefinert                                    │    │
│  │  Lag egen blokk                                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 11.2 Velg test

```
┌─────────────────────────────────────────────────────────────┐
│  ← Tilbake                           Velg test              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  🔍 Søk etter test...                                       │
│                                                              │
│  Filter: [ Alle ▼ ]  [ Kortspill ▼ ]  [ Putting ▼ ]        │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  KORTSPILL                                                  │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Innspill 100m test                                 │    │
│  │  20 slag • 15-20 min • Presisjon                    │    │
│  │  Krav B-kategori: 65%                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Innspill 50m test                                  │    │
│  │  20 slag • 15-20 min • Presisjon                    │    │
│  │  Krav B-kategori: 70%                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  PUTTING                                                    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Putting 1.5m test                                  │    │
│  │  20 putter • 10-15 min • Make percentage            │    │
│  │  Krav B-kategori: 85%                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Putting distanse test                              │    │
│  │  10 putter • 10 min • Avstandskontroll              │    │
│  │  Krav B-kategori: 90% innenfor 1m                   │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  LANGSPILL                                                  │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Driver dispersion test                             │    │
│  │  10 slag • 15 min • Spredning                       │    │
│  │  Krav B-kategori: 80% i fairway                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 11.3 Test som blokk

Når test er valgt, vises den som vanlig blokk med ekstra felt:

```
┌─────────────────────────────────────────────────────────────┐
│  BLOKK 3: TEST                                   20 min     │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │  📊 Innspill 100m test                              │    │
│  │  Fokus: Presisjon                                   │    │
│  │                                                      │    │
│  │  Treningsområde                                     │    │
│  │  Innspill 90-110 meter                              │    │
│  │                                                      │    │
│  │  Volum                                              │    │
│  │  20 slag                                            │    │
│  │                                                      │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │  Ditt krav (B-kategori): 65%                │   │    │
│  │  │  Din beste: 68%                              │   │    │
│  │  │  Din siste: 62%                              │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                      │    │
│  │  ┌────────┐ ┌────────┐ ┌────────┐                  │    │
│  │  │  Test  │ │ CS100% │ │  M3    │                  │    │
│  │  └────────┘ └────────┘ └────────┘                  │    │
│  │                                                      │    │
│  │  [ Se full testbeskrivelse ▼ ]                     │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

## 12. Del økt med spiller

> **Funksjon:** Del økt med andre spillere (venner)
> **Tilgang:** Via meny (⋮) på økt-detaljsiden

---

### 12.1 Del økt-modal

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  Del økt                                           ✕        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Treningsøkt: Langspill fokus                               │
│  Mandag 16. desember • 120 min • 4 blokker                 │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Velg mottakere                                             │
│                                                              │
│  🔍 Søk etter spiller...                                    │
│                                                              │
│  MINE VENNER                                                │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ☐  👤 Ole Hansen                                   │    │
│  │      B-kategori • Samme klubb                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ☑  👤 Kari Nordmann                                │    │
│  │      B-kategori • Annen klubb                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ☐  👤 Erik Svendsen                                │    │
│  │      C-kategori • Samme klubb                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ☑  👤 Lisa Pettersen                               │    │
│  │      A-kategori • Annen klubb                       │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Beskrivelse (valgfritt)                                   │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Hei! Her er økten jeg brukte i dag. Fungerte      │    │
│  │  veldig bra for innspill. Anbefaler å starte med   │    │
│  │  pyramiden for å varme opp teknikken.              │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Delingsalternativer                                       │
│                                                              │
│  ☑  Del som mal (mottaker kan redigere)                    │
│  ☐  Del resultat (inkluder mine data fra økten)            │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Del med 2 spillere ]                     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 12.2 Mottatt økt

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  📩 Ny delt økt                                             │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                              │
│  Fra: Per Olsen                                             │
│  Delt: 16. desember 2025, 14:32                            │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                      │    │
│  │  Treningsøkt: Langspill fokus                       │    │
│  │  120 min • 4 blokker                                │    │
│  │                                                      │    │
│  │  • Blokk 1: Pyramiden (30 min)                      │    │
│  │  • Blokk 2: Scattered (30 min)                      │    │
│  │  • Blokk 3: 9-holes putting (30 min)                │    │
│  │  • Blokk 4: Fysisk mobilitet (30 min)               │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Melding fra Per:                                           │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  "Hei! Her er økten jeg brukte i dag. Fungerte     │    │
│  │  veldig bra for innspill. Anbefaler å starte med   │    │
│  │  pyramiden for å varme opp teknikken."             │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Legg til i mine økter ]                  │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          [ Se detaljer ]                            │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│                    [ Avvis ]                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 12.3 Venner-system

| Funksjon | Beskrivelse |
|----------|-------------|
| **Legg til venn** | Send venneforespørsel via brukernavn/e-post |
| **Godkjenn forespørsel** | Aksepter/avvis innkommende forespørsler |
| **Venner-liste** | Se alle venner med status |
| **Fjern venn** | Fjern fra venner-listen |
| **Blokker** | Blokker bruker fra å kontakte deg |

---

### 12.4 Data for deling

| Felt | Type | Beskrivelse |
|------|------|-------------|
| **sessionId** | UUID | Økt som deles |
| **senderId** | UUID | Avsender |
| **recipientIds** | Array[UUID] | Mottakere |
| **message** | String | Beskjed fra avsender |
| **shareAsTemplate** | Boolean | Del som redigerbar mal |
| **includeResults** | Boolean | Inkluder treningsdata |
| **sharedAt** | DateTime | Tidspunkt for deling |
| **status** | Enum | Pending/Accepted/Declined |

---

### 12.5 Videre utvikling

**TODO:**
- [ ] Integrering med Apple Watch
- [ ] Lydsignaler ved blokkbytte
- [ ] Video-opptak per blokk
- [ ] Deling til trener i sanntid
- [ ] Gruppetrening (synkroniserte økter)

---

## Sekundære skjermer

### Testgjennomføring
- Testbeskrivelse
- Instruksjoner
- Input for resultater
- Automatisk beregning av score
- Sammenligning med krav

### Chat/Meldinger
- Samtaler med trener
- Gruppesamtaler (team)
- Fil- og bildedeling
- Lesebekreftelser

---

## Brukerroller

| Rolle | Tilgang |
|-------|---------|
| **Spiller** | Alt ovenfor |
| **Trener** | + Se spilleres data, lage planer |
| **Admin** | + Brukeradministrasjon |

---

## Prioritert utviklingsrekkefølge

1. **MVP (Fase 1)**
   - Dashboard med dagens økter
   - Kalender ukevisning
   - Grunnleggende statistikk

2. **Fase 2**
   - Mål med progress
   - Merker/achievements
   - Profil med innstillinger

3. **Fase 3**
   - Chat/meldinger
   - Avansert statistikk
   - Kalender-sync

4. **Fase 4**
   - Trenerportal
   - Rapporter
   - Eksport

---

*Spesifikasjon v1.0 - AK Golf Academy*
