# Coach/admin 



### Dashbaord 



Jeg skriver i tilfeldig rekkefølge. Sorter de ulike etter logikk og sammenheng 

##### 

- Mine grupper 
  - Oversikt over mine grupper 
- Mine spillere 
  - Oversikt over alle spillere kommer på hovedskjerm 
  - Oversikt over 
    - Ukens turnering og hvilke spillere som spiller hvor 
    - Om spillere har registert sykdom / skade 
    - Rød flagg fra spillere: Lite søvn, mat osv 
    - Annet relevante visninger?? Kom med forslag 
- Bookingsystem 
  - Modul for Booking slår inn (Denne skal være ferdig i mappen)
- Stats verktøy 
  - Stats mine spillere 
    - Viser oversikt fremgang på spillere 
    - Viser tilbakegang spillere 
    - Andre relevante punkter 
  - Stats verkøty 
    - Modeul fra Data Golf 
- Treningsplanlegger 
  - Her kan trener velge spiller 
    - Trener får oversikt over spillerens 
      - Årsplan 
      - Periodeplan 
      - Månedplan 
      - Ukeplan 
      - Øktplaner 
    - Trener kan gjøre endringer i planen 
      - Når trener gjør endring blir spiller varslet 
  - Trener kan velge grupper 
    - Trener får oversikt over treningsplan for gruppe (f.eks WANG Toppidrett / Team Norway)
    - Trener kan her endre treningsplan 
    - Når endring er gjort vil det sendes beskjed i gruppen og automatisj endring i spiller treningsplan som er medlem av denne spesifikke gruppen 
- Turneringskalender 
  - Full turneringskaleder 
  - Mine spillere 
- Beskjed / Chat 
  - Planlegg beksjed 
    - Velger dato 
    - Tidpsunkt 
    - Skriver en beksjed 
      - Velger spillere 
      - Velger gruppe 
      - Kan legge ved vedlegg 
    - Beskjed står på automatisk sending på dato/tidspunkt/spiller/gruppe
- Øvelsesbank
  - Øvelser 
  - Treningsplaner 
  - OSv 