export { default as CoachAthleteDetail } from "./CoachAthleteDetail";
