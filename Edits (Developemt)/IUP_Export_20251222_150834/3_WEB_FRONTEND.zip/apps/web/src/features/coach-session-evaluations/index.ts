/**
 * Coach Session Evaluations Feature
 *
 * Allows coaches to view their athletes' session evaluations
 */

export { CoachSessionEvaluations, default } from './CoachSessionEvaluations';
