#### Dashboard 

#### Planlegger 

- Årsplan 
- Periodeplaner 
- Turneringer 
- Samling 
- Skole 

#### Kalender 

- Årsplan 
- Periodeplaner 
- Treningsplan 
- Turneringsplan 

#### Trening

- Dagens treninsplan 
- Ukens treningsplan 
- Øvelsesbank 
- Teknisk plan 

#### Stats 

- Ny stats oppdatering 
- Turneringsstatistikk 
- Stats verktøy 

#### Evaluering

- Alle evalueringer 
- Trening
- Turnering 

#### Kunnskap 

- Artikler og verktøy 
- Notater 



Hvilke andre databaser har vi lagd som mangler?