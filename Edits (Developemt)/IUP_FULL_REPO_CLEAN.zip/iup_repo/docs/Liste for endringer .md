## Endringer 







Fysiskeverdier 