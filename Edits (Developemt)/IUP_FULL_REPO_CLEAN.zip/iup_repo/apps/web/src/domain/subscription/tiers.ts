export enum SubscriptionTier {
  PLAYER_BASE = "player_base",
  PLAYER_PREMIUM = "player_premium",
  PLAYER_ELITE = "player_elite",

  COACH_BASE = "coach_base",
  COACH_PRO = "coach_pro",
  COACH_TEAM = "coach_team",
}
