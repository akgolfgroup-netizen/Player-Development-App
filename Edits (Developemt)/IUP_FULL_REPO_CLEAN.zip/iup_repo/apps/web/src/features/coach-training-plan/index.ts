export { default as CoachTrainingPlan } from "./CoachTrainingPlan";
